'''
Created on Feb 19, 2018

@author: Louis
'''

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
        
    '''
    Function that adds a pattern to the grid
    input: name of the pattern, coordinates x and y 
    '''    
    def addPattern(self, patternname,x,y):
        pattern = self.__repo.readPattern(patternname)
        self.__repo.addPattern(pattern,x,y)
        print("Pattern added!\n\n")

    def setDead(self):
        self.__repo.establishDead()
    
    '''
    Function that creates a new generation
    '''    
    def makeGeneration(self):
        self.__repo.generation() 
        
    def loadsave(self, command, filename):
        if command == 'load':
            self.__repo.loadGame(filename)
        if command == 'save':
            self.__repo.saveGame(filename)
        
    def getTable(self):
        return self.__repo.__str__()