'''
Created on Feb 19, 2018

@author: Louis
'''

class Repository(object):
    def __init__(self, _patternfile):
        self.__patternfile = _patternfile
        self.__alive = []
        self.__dead = []
        
    def establishDead(self):
        self.__dead = []
        for i in range(8):
            for j in range(8):
                if [i,j] not in self.__alive:
                    self.__dead.append([i,j])    
        
    '''
    Function that creates a single generation movement
    '''   
    def generation(self):
        print(self.__alive)
        self.establishDead()
        for x in self.__alive:
            count = self.countLiveNeigh(x[0], x[1])
            if count < 2:
                self.__alive.remove(x)
                self.__dead.append(x)
            if count == 2 or count == 3:
                pass
            if count > 3:
                self.__alive.remove(x)
                self.__dead.append(x)
        
        for x in self.__dead:
            count = self.countLiveNeigh(x[0], x[1])
            if count == 3:
                self.__dead.remove(x)
                self.__alive.append(x)
                
        print(self.__str__())
        
        
    def validateCell(self,x,y):
        x = int(x)
        y = int(y)
        
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        if [x,y] in self.__alive:
            return 1
        return 2
    
    def getNeigh(self,x,y):
        neigh = []
        for i in range(-1,2):
            for j in range(-1,2):
                if ([x,y] != [x+i,y+j]) and self.isOkay(x+i, y+j):
                    neigh.append([x+i,y+j])
        return neigh
    
    def isOkay(self,x,y):
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        return 1
    
    def countLiveNeigh(self,x,y):
        count = 0
        
        neigh = self.getNeigh(x, y)
        for x in neigh:
            if x in self.__alive:
                count+=1
        
        return count
    
    def isAlive(self,x,y):
        if [x,y] in self.__alive:
            return True
        return False
    
    def isDead(self,x,y):
        if [x,y] in self.__dead:
            return True
        return False
    
    def readPattern(self, patternname):
        with open(self.__patternfile,"r") as f:
            for line in f.readlines():
                line = line.strip()
                arr = line.split("-")
                if arr[0] == patternname:
                    pat = arr[1]

                    pattern = pat.split(';')
                    
                    final = []
                    
                    for x in pattern:
                        x = x.split(',')
                        x[0] = int(x[0])
                        x[1] = int(x[1])
                        y = []
                        y.append(x[0])
                        y.append(x[1])
                        final.append(y)
                    
                    
                    return final
    
    
            
    def saveGame(self, filename):
        self.__slfile = filename
        with open(self.__slfile, "w") as f:
            for x in self.__alive:
                f.write(str(x[0]))
                f.write(',')
                f.write(str(x[1]))
                
                f.write('\n')

    def loadGame(self, filename):
        self.__slfile = filename
        with open(self.__slfile, "r") as f:
            for line in f.readlines():
                line = line.strip()
                line = line.split(',')
                self.__alive.append([int(line[0]),int(line[1])])
        print(self.__str__())
    
    '''
    Function that adds a pattern
    input: the cells assigned to the shape of the pattern as a list, coordinates x and y 
    '''
    def addPattern(self, pattern, x,y):
        x = int(x)-1
        y = int(y)-1
        for p in pattern:
            ans = self.validateCell(x+int(p[0]), y+int(p[1]))
            if ans == 2:
                self.__alive.append([x+int(p[0]) , y+int(p[1])])
                self.__dead.remove([x+int(p[0]) , y+int(p[1])])
            if ans == 0:
                print("Some cell is outside the board!")
                return 0
            if ans == 1:
                print("Some cell overlays an existing alive cell!")
                return 1
        return 2
            
        
    
        
        
    def generateTable(self):
        table = [None]*8
        for i in range (8):
            table[i] = [' ']*8
        return table
                    
        
    def __str__(self):
        table = self.generateTable()
        s = ' |1|2|3|4|5|6|7|8|\n'
        for x in self.__alive:
            table[int(x[0])][int(x[1])] = 'X'
         
               
        for i in range(8):
            s+=str(i+1)
            for j in range(8):
                s+="|"+table[i][j]
            s+="|\n"
            
        
        
        return s
        
        