'''
Created on Feb 19, 2018

@author: Louis
'''
import unittest
from repository.Repository import Repository


class TestRepo(unittest.TestCase):


    def testName(self):
        self.__repo = Repository('patterns.txt')
        self.__repo.__alive = []
        self.__repo.establishDead()
        pattern = self.__repo.readPattern('block')
        self.assertEqual(self.__repo.addPattern(pattern, 1, 1), 2)
        
        self.assertEqual(self.__repo.addPattern(pattern, 1, 1), 1)
        
        #self.assertEqual(self.__repo.addPattern(pattern, 5, 5), 2)
        
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()