'''
Created on Feb 19, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
    def __read_command(self):
        return input("Enter command: ")
        
        
    def run(self):
        print(self.__controller.getTable())
        while True:
            self.__controller.setDead()
            command = input("Enter command: ")
            arr = command.split(' ')
            if arr[0] == 'place':
                if arr[1] in ['block','tub','blinker','beacon','spaceship']:
                    self.__controller.addPattern(arr[1], arr[2], arr[3])
                    print(self.__controller.getTable())
                else:
                    print("No such pattern exists! Try again: ")
            if arr[0] == 'tick':
                if len(arr) == 2:
                    for i in range(0,int(arr[1])):
                        self.__controller.makeGeneration()
            if arr[0] == 'save' or arr[0] == 'load':
                self.__controller.loadsave(arr[0], arr[1])
                
                
                    
            
            