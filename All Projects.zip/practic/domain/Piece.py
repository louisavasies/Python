'''
Created on Feb 3, 2018

@author: Louis
'''

class Piece(object):
    
    def __init__(self, _x, _y, _sign):
        self.__x = _x
        self.__y = _y 
        self.__sign = _sign

    def get_x(self):
        return self.__x


    def get_y(self):
        return self.__y

    def get_sign(self):
        return self.__sign
    
    def set_sign(self, sign):
        self.__sign  = sign

        
    def pieceValidate(self):
        if (int(self.__x) < 0 or int(self.__x) > 2 or int(self.__y) < 0 or int(self.__y) > 2 or self.__sign != "X" or self.__sign != "O"):
            return 1
        return 0
    
    @staticmethod
    def pieceToStr(piece):
        return str(piece.get_x()) + ";" + str(piece.get_y()) + ";" + piece.get_sign()
    
    @staticmethod
    def strToPiece(line):
        words = line.split(";")
        return Piece( int(words[0]) , int(words[1]) , words[2])

