'''
Created on Feb 3, 2018

@author: Louis
'''

from domain.Piece import Piece
import random

class Table(object):

    def __init__(self):
        self.__player = []
        self.__AI = []
    
    
    def findPiece(self,x,y,sign):
        if sign == "X":
            poz = 0
            for p in self.__player:
                if (p.get_x() == x and p.get_y() == y):
                    return poz
                poz += 1
        elif sign == "O":
            poz = 0
            for p in self.__AI:
                if (p.get_x() == x and p.get_y() == y):
                    return poz
                poz += 1
        return 0
    
    def remove_piece(self,x,y,sign):
        if self.findPiece(x,y,sign) != 0:
            poz = self.findPiece(x,y,sign)
        if sign == "X":
            self.__player.pop(poz)
        elif sign == "O":
            self.__AI.pop(poz)
    
    
    def notOccupied(self, piece):
        if piece in self.__player or piece in self.__AI:
            return 0
        return 1
        
    def addPiece(self, piece):
        if piece.get_sign() == "X":
            self.__player.append([piece.get_x(), piece.get_y()])
            return 1
        elif piece.get_sign() == "O":
            self.__AI.append([piece.get_x(), piece.get_y()])
            return 1
        return 0
        
            
    
    def genPiece(self):
        sign = "O"
        x = random.randint(0,2)
        y = random.randint(0,2)
        piece = Piece(x, y, sign)
        if self.notOccupied(piece):
            return piece
        else:
            while not self.notOccupied(piece):
                x = random.randint(0,2)
                y = random.randint(0,2)
                piece = Piece(x, y, sign)
        return piece
            
        
    
        
    
    
    def generateTable(self):
        table = [None]*3
        for i in range (0, 3):
            table[i] = ['-']*3
        return table
    
    def __str__(self):
        table = self.generateTable()
        for x in self.__player:
            table[x._get_x, x._get_y] = 'X'
        for y in self.__AI:
            table[y._get_x, y._get_y] = 'O'
        s = ""
        for i in range(2):
            for j in range(2):
                s+=str(table[i][j])
            s+="\n"
               
        return s
    
    

    
                