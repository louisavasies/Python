'''
Created on Feb 3, 2018

@author: Louis
'''
from UI.Console import Console
from controller.Controller import Controller
from repository.Repository import Repository
from domain.Table import Table


class App(object):
    def main(self):
        table = Table()
        repo = Repository("pieces.txt", table)
        contr = Controller(repo)

        cons = Console(contr)
        cons.run()



if __name__ == '__main__':
        app = App()
        app.main()

