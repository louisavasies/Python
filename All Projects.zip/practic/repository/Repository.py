'''
Created on Feb 3, 2018

@author: Louis
'''
from domain.Piece import Piece



class Repository(object):

    def __init__(self, _file_name, _table):
        self.__file_name = _file_name
        self.__table = _table
        
    
    
    '''
    Function that changes a piece into an unused space (for Movement Phase)
    input: piece to ne changed, x,y - coord of the place we move the piece into
    
    '''
    def interchange_pieces(self, piece, x,y):
        var = Piece(x,y,piece.get_sign())
        sign = piece.get_sign()
        piece.set_sign("-")
        self.__table.remove_piece(piece.get_x(), piece.get_y(), sign)
        self.addPieceOnTable(var)
    '''
    Function for adding a piece on the table
    Input: piece
    Output: 0-not added, 1-added
    '''  
    def addPieceOnTable(self, piece):
        if self.__table.addPiece(piece):
            return 1
        return 0
    
    '''
    Function that generates a table of 3x3
    Input:-
    Output:table
    '''
    def gen_table(self):
        table = self.__table.generateTable()
        return table
        
    '''
    Function that creates a piece for the human player
    Input:x,y -coordinates
    Output: piece
    '''
    def setPieceForHuman(self, x, y):
        piece = Piece(x,y,"X")
        if not piece.pieceValidate():
            return 0
        return piece
    
    '''
    Function for creating a piece for the AI
    Input:-
    Ouput: piece
    '''
    def setPieceForAI(self):
        piece = self.__table.genPiece();
        return piece    
        
    '''
    Function to load pieces from a .txt file
    '''   
    def load_pieces(self):
        with open(self.__file_name,"r") as f:
            for line in f.readlines():
                line = line.strip()
                arr = line.split(",")
                s = Piece(int(arr[0]), int(arr[1]), arr[2])
                self.add_item(s)
    
    '''
    Function for saving a piece to a txt file
    '''
    def save_pieces(self, Piece):
        with open(self.__file_name, "w") as f:
            s = str(Piece.get_x())+","+str(Piece.get_y())+","+Piece.get_sign()+"\n"
            f.write(s)
            
            
            
            
            
