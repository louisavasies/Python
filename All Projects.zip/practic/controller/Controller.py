'''
Created on Feb 3, 2018

@author: Louis
'''


class Controller(object):
    
    def __init__(self, repository):
        self.__repository = repository
        
    '''
    Function for moving a piece to an unoccupied place
    Input:piece to move, x,y-new coordinated to move to
    Output:-
    '''
    def move_piece(self, piece, x,y):
        self.__repository.interchange_pieces(piece,x,y)
        
    '''
    Function for adding a piece
    Input:piece
    Output:1 or 0, depending on wheter the piece has been added or not
    '''
    def add_piece(self, piece):
        ans = self.__repository.addPieceOnTable(piece)
        return ans
    '''
    Function for generating a table
    Input:-
    Output:table
    '''
    def generateTable(self):
        table = self.__repository.gen_table()
        return table
    '''
    Function for generating a piece for the AI
    Input:-
    Output:piece
    '''
    def generateAIPiece(self):
        piece = self.__repository.setPieceForAI()
        return piece
    '''
    Function for generating a piece for the player
    Input: desired coordinates x and y 
    Output:piece 
    '''
    def generatePlayerPiece(self, x,y):
        piece = self.__repository.setPieceForHuman(x,y)
        return piece
    
    '''
    Function for saving a piece into a log file
    Input: piece
    Output: 1 if saved
    '''
    def save_item(self, piece):
        self.__repository.save_pieces(piece)
        return 1
    