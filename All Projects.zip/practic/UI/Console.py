'''
Created on Feb 3, 2018

@author: Louis
'''
from domain.Piece import Piece

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
        
    def __read_command(self):
        return input("Input option:")
    
    def __showMenu(self,options):
        print("0.Exit")
        keys = options.keys()
        for option in keys:
            print(options[1])
        
    
    def ui_gen_table(self):
        table = self.__controller.generateTable()
        s = table.__str__()
        print(s)
        
    def ui_gen_piece(self, sign):
        x = input("Enter x: ")
        y = input("Enter y: ")
        if self.__controller.generatePlayerPiece(x,y):
            print("Piece " + "(" + str(x) + ";" + str(y) + ") added with succes!")
            self.__controller.save_item(Piece(x,y,"X"))
        else:
            print("Piece " + "(" + str(x) + ";" + str(y) + ") is not valid!")
            gata = False
            while not gata:
                x2 = input("Enter x: ")
                y2 = input("Enter y: ")
                piece2 = Piece(x2,y2,sign)
                ans = self.__controller.add_piece(piece2)
                if ans:
                    gata = True
                    print("Piece " + "(" + str(x) + ";" + str(y) + ") added with success!")
                    self.__controller.save_item(piece2)
                    
            
        
    def ui_gen_piece_AI(self):
        piece = self.__controller.generateAIPiece()
        if self.__controller.add_piece(piece):
            print("AI placed piece (" +str(piece.get_x()) + ";"+str(piece.get_y()) +") with success!")
            self.__controller.save_item(piece)
            
    def ui_move_piece(self,piece,x,y):
        self.__controller.move_piece(piece)
        
    
    
    def start_game(self):
        table = self.ui_gen_table()
        for i in range (0,3):  # @UnusedVariable
            sign = "X"
            self.ui_gen_piece(sign)
            s = table.__str__()
            print(s)
            self.ui_gen_piece_AI()
            s = table.__str__()
            print(s)
            
            
    def print_all_options(self):
        print("1.Start game! ")


    def run(self):
        while True:
            self.__controller.generateTable()
            self.print_all_options()
            options = {1:self.start_game()}
            op = int(input("Enter options: "))
            options[op]()
            if op == 0:
                return False
                
            
