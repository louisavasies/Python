'''
Created on Jan 17, 2018

@author: Louis
'''
from controller.Controller import Controller
from repository.Repository import FileRepository
from ui.Console import Console
from domain.Car import Car

class App(object):
    def main(self):
        car_repo = FileRepository("cars.txt", Car.strToCar, Car.carToStr)
        c = Controller(car_repo)

        cons = Console(c)
        cons.run()



if __name__ == '__main__':
    try:
        app = App()
        app.main()
    except Exception as ex:
        print("Exceptie in aplicatie: ", ex)
