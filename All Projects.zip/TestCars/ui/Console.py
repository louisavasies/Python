'''
Created on Jan 17, 2018

@author: Louis
'''
from domain.Validators import StoreError


def carToStr(car):
    return (str(car.get_id()) + "--" + car.get_type() + "--" + car.get_brand() + "--" 
        + str(car.get_eng_power()) + "--" + str(car.get_avg_speed()) + "--TOP SPEED--" + str(car.get_top_speed()))


class Console(object):
    def __init__(self, controller):
        self.__controller = controller
        
    def add_cars(self):
        try:
            Id = int(input("Enter id: "))
            Type = input("Enter type: ")
            brand = input("Enter brand: ")
            engp = int(input("Enter engine power: "))
            avgsp = int(input("Enter average speed: "))
            
            self.__controller.add_Car(Id, Type, brand, engp, avgsp)
        except StoreError as se:
            print(se)
        
    def swap_engines(self):
        id1 = int(input("Enter first id: "))
        id2 = int(input("Enter second id: "))
        cars = self.__controller.swap_Engines(id1, id2)
        for c in cars:
            print(carToStr(c))
            
    def top5Speed(self):
        cars = self.__controller.Top5Cars()
        for i in range(5):
            print(carToStr(cars[i]))
            
            
    def print_all_options(self):
        print("1.Add a car\n2.Swap engines between two cars\n3.See TOP 5 cars by top speed\n ")


    def run(self):
        while True:
            self.print_all_options()
            options = {1:self.add_cars,2:self.swap_engines,3:self.top5Speed}
            try:
                op = int(input("Enter options: "))
                options[op]()
                if op == 0:
                    return False
            except ValueError:
                print("Wrong choice")
                return


    
        