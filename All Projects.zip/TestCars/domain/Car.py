'''
Created on Jan 17, 2018

@author: Louis
'''
from builtins import staticmethod

class Car(object):
    
    
    def __init__(self, _id, _type, _brand, _eng_power, _avg_speed):
        self.__id = _id
        self.__type = _type
        self.__brand = _brand
        self.__eng_power = _eng_power
        self.__avg_speed = _avg_speed
        self.__top_speed = _eng_power* _avg_speed

    def get_top_speed(self):
        return self.__top_speed


        
    def validate_type(self):
        if self.get_type() not in ('A','B','C'):
            return 0
        return 1
    
    def validate_brand(self):
        if self.get_brand() not in ('Mercedes', 'Audi', 'BMW'):
            return 0
        return 1

    def get_id(self):
        return self.__id


    def get_type(self):
        return self.__type


    def get_brand(self):
        return self.__brand


    def get_eng_power(self):
        return self.__eng_power


    def get_avg_speed(self):
        return self.__avg_speed


    def set_type(self, value):
        self.__type = value


    def set_brand(self, value):
        self.__brand = value


    def set_eng_power(self, value):
        self.__eng_power = value


    def set_avg_speed(self, value):
        self.__avg_speed = value
        
    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__id == other.__id
    
    
    
    @staticmethod
    def carToStr(car):
        return str(car.get_id()) + ";" + car.get_type() + ";" + car.get_brand() + ";" + str(car.get_eng_power()) + ";" + str(car.get_avg_speed())
    
    @staticmethod
    def strToCar(line):
        words = line.split(";")
        return Car(int(words[0]), words[1], words[2], int(words[3]), int(words[4]))
    top_speed = property(get_top_speed, None, None, None)
