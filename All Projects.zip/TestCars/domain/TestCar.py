'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
from domain.Car import Car


class TestCar(unittest.TestCase):


    def setUp(self):
        self._id = 0
        self._type = 'A'
        self._brand = 'BMW'
        self._eng_power = 286
        self._avg_speed = 260
        
        self._car1 = Car(self._id, self._type, self._brand, self._eng_power, self._avg_speed)
        
        self._otherid = 0
        self._anotherid = 1
        self._othertype = 'B'
        self._othereng = 272
        self._car2 = Car(self._otherid, self._othertype, self._brand, self._eng_power, self._avg_speed)
        self._car3 = Car(self._anotherid, self._othertype, self._brand, self._othereng, self._avg_speed)


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._car1.get_id(), 0)
        self.assertEqual(self._car1.get_type(), 'A' )
        self.assertEqual(self._car1.get_brand(), 'BMW' )
        self.assertEqual(self._car1.get_eng_power(), 286 )
        self.assertEqual(self._car1.get_avg_speed(), 260 )
        
        
        
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()