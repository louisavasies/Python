'''
Created on Jan 17, 2018

@author: Louis
'''

class StoreError(Exception):
    def __init__(self, message=None, ex=None):
        Exception.__init__(self, message)
        self.__ex = ex
        self.__message = message

    @property
    def message(self):
        msg = self.__message if self.__message else ""
        if self.__ex is None:
            return msg
        msg = msg + " " + type(self.__ex).__name__ + ": " + str(self.__ex)
        return msg

    def __str__(self):
        return self.message


class ValidatorError(StoreError):
    pass

class CarValidator(object):
    def validate(self, car):
        errors = []
        if not type(car._id) is int or car._id < 0:
            errors.append("Car Id must be an integer greater or equal to 0")
        if not car._type in ('A','B','C'):
            errors.append("Type must be of type A, B or C")
        if not car._brand in ('Mercedes', 'BMW', 'Audi'):
            errors.append("Brand must be Mercedes, BMW or Audi")
        if not type(car._eng_power) is int or car._eng_power < 100:
            errors.append("Engine power must be an inetegr greater or equal to 100")
        if not type(car._avg_speed) is int or car._avg_speed < 100:
            errors.append("Average speed must be an inetegr greater or equal to 100")
        if len(errors) > 0:
            raise ValidatorError(str(errors))
               
