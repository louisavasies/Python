'''
Created on Jan 17, 2018

@author: Louis
'''

from domain import Car
from domain.Validators import ValidatorError, StoreError

def carToStr(car):
    return (str(car.get_id()) + "--" + car.get_type() + "--" + car.get_brand() + "--" 
        + str(car.get_eng_power()) + "--" + str(car.get_avg_speed()) + "--TOP SPEED--" + str(car.get_top_speed()))

class Controller(object):
    def __init__(self, repository):
        self.__repo = repository
        
    def get_all(self):
        return self.__repository.get_all()
    
    def add_Car(self, Id, Type, Brand, EngP, AvgSp):
        car = Car(Id, Type, Brand, EngP, AvgSp)
        try:
            self.__repo.add(car)
        except ValidatorError as ve:
            raise StoreError(ex=ve)
        
    def swap_Engines(self, id1, id2):
        return self.__repo.swap_engines(id1, id2)
            
    def Top5Cars(self):
        return self.__repo.top5TopSpeed()
         
    def print_cars(self):
        return self.__repository.get_all()