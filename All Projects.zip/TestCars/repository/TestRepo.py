'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
from domain.TestCar import TestCar
from domain.Car import Car
from repository.Repository import Repository, FileRepository, RepoException


class TestRepo(unittest.TestCase):


    def setUp(self):
        TestCar.setUp(self)
        self._repo = FileRepository("cars.txt", Car.strToCar, Car.carToStr)


    def tearDown(self):
        pass


    def testName(self):
        TestCar.testName(self)
        self.assertEqual(self._repo.size(), 0)
        self._repo.add(self._car1)
        self.assertEqual(self._repo.size(), 1)
        
        with self.assertRaises(RepoException):
            self._repo.add(self._car1)
        with self.assertRaises(RepoException):
            self._repo.add(self._car2)
            
        self._carr = self._repo.find(self._car1)
        self.assertEqual(self._carr.get_id(), 0)
        
        self._repo.add(self._car3)
        self._repo.swap_engines(0, 1)
        self.assertEqual(self._car1.get_eng_power(), 272)
        self.assertEqual(self._car2.get_eng_power(), 286)
        
        self._cars = []
        self._cars = self._repo.top5TopSpeed()
        
        self.assertEqual(self._cars[0], self._car3)
        
        
        
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()