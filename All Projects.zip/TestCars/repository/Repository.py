'''
Created on Jan 17, 2018

@author: Louis
'''

from operator import attrgetter

class Repository(object):
    def __init__(self):
        self._elems = []
        
    def add(self, elem):
        if elem in self._elems:
            raise RepoException("Car already exists!")
        if elem.validate_type() == 0 or elem.validate_brand == 0:
            raise Exception("Wrong type or brand!")
        self._elems.append(elem)
    
    def find_by_id(self, Id):
        for elem in self._elems:
            if elem.get_id() == Id:
                return elem
        raise RepoException("A car with such an Id was not found!")
    
    
    def find(self, elem):
        if not elem in self._elems:
            raise RepoException("Car is not in repo!")
        return self._elems[elem.get_id()]
    
    def size(self):
        return len(self._elems)
    
    def swap_engines(self, id1, id2):
        car1 = self.find_by_id(id1)
        car2 = self.find_by_id(id2)
        if (car1.get_type() == 'A' and car2.get_type == 'C') or (car1.get_type() == 'C' and car2.get_type == 'A'):
            raise Exception("Too much of a difference between types")
        if (car1.get_brand() != car2.get_brand()):
            raise Exception("Different brands!")
        aux_eng = car1.get_eng_power()
        car1.set_eng_power(car2.get_eng_power())
        car2.set_eng_power(aux_eng)
        print("Swap successful!")
        return self._elems
    
    def top5TopSpeed(self):
        cars = []
        for car in self._elems:
            cars.append(car)
        cars.sort(key = attrgetter("top_speed"), reverse = True)
        return cars
        
            
        
    


class FileRepository(Repository):
    def __init__(self, txt, str_to_car, car_to_str):
        self.__txt = txt
        self.__strToObj = str_to_car
        self.__objToStr = car_to_str
        Repository.__init__(self)
        self.__readAllFromFile()
    
    def __readAllFromFile(self):
        with open(self.__txt,"r") as f:
            for line in f.readlines():
                line = line.strip()
                if len(line)>0:
                    obj = self.__strToObj(line)
                    self._elems.append(obj)
    
    def __writeAllToFile(self):
        with open(self.__txt,"w") as f:
            for obj in self._elems:
                line = self.__objToStr(obj)
                f.write(line+"\n")
    
    def add(self, elem):
        Repository.add(self, elem)
        self.__writeAllToFile()

    

    


class RepoException(Exception):
    pass


