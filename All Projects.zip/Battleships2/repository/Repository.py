'''
Created on Feb 13, 2018

@author: Louis
'''
import random

class Repository(object):
    def __init__(self):
        self.__H_ships = []
        self.__H_hits = []
        self.__C_ships = []
        self.__C_hits = []
        
    def checkShips(self, player):
        if player == 'H':
            for x in self.__H_ships:
                if not x in self.__C_hits:
                    return 0
            return 1
        if player == 'C':
            for x in self.__C_ships:
                if not x in self.__H_hits:
                    return 0
            return 1
        
    def addHitHuman(self,x,y):
        x = int(x)
        y = int(y)
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        if [x,y] in self.__H_hits:
            return 1
        self.__H_hits.append([x,y])
        
        return 2
    
    def validateHit(self,x,y):
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        return 1
    
    def addHitComputer(self):
        gasit = False
        for x in self.__C_hits:
            if x in self.__H_ships:
                gasit = True
        if not gasit:
            x = random.randint(0,8)
            y = random.randint(0,8)
            self.__C_hits.append([x,y])
            if [x,y] in self.__H_ships:
                self.__H_ships.remove([x,y])
        else:
            poz = random.randint(0,len(self.__C_hits))
            lov = self.__C_hits[poz]
            i = random.randint(-4,5)
            j = random.randint(-4,5)
            x = lov[0]
            y = lov[1]
            ans = self.validateHit(x+i, y+j)
            while not ans:
                i = random.randint(-4,5)
                j = random.randint(-4,5)
                ans = self.validateHit(x+i, y+j)
            self.__C_hits.append([x+i,y+j])
            
        
        
    def addShip(self,x,y,lung,ori,side):
        if self.validateShip(x, y, lung, ori, side, 'H') == 2:
            if ori == 'H':
                if side == 'L':
                    for i in range(0,lung):
                        self.__H_ships.append([x,y+i])
                if side == 'R':
                    for i in range(0,lung):
                        self.__H_ships.append([x,y-i])
            if ori == 'V':
                if side == 'U':
                    for i in range(0,lung):
                        self.__H_ships.append([x+i,y])
                if side == 'D':
                    for i in range(0,lung):
                        self.__H_ships.append([x-i,y])
            s = self.__str__('H')
            print(s)
            return 1
        return self.validateShip(x, y, lung, ori, side, 'H')
        
    def validateShip(self,x,y,lung,ori,side,player):
        x = int(x)
        y = int(y)
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        if player == 'H':
            if ori == 'H':
                if side == 'L':    
                    if y + lung - 1 > 7:
                        return 1
                    for i in range(0,lung):
                        if [x,y+i] in self.__H_ships:
                            return 1
                if side == 'R':
                    if y - lung + 1 < 0:
                        return 1
                    for i in range(0,lung):
                        if [x,y-i] in self.__H_ships:
                            return 1
            if ori == 'V':
                if side == 'U':
                    if x + lung - 1 > 7:
                        return 1
                    for i in range(0,lung):
                        if [x+i,y] in self.__H_ships:
                            return 1
                if side == 'D':
                    if x - lung + 1 < 0:
                        return 1
                    for i in range(0,lung):
                        if [x-i,y] in self.__H_ships:
                            return 1
        if player == 'C':
            if ori == 'H':
                if side == 'L':    
                    if y + lung - 1 > 7:
                        return 1
                    for i in range(0,lung):
                        if [x,y+i] in self.__C_ships:
                            return 1
                if side == 'R':
                    if y - lung + 1 < 0:
                        return 1
                    for i in range(0,lung):
                        if [x,y-i] in self.__C_ships:
                            return 1
            if ori == 'V':
                if side == 'U':
                    if x + lung - 1 > 7:
                        return 1
                    for i in range(0,lung):
                        if [x+i,y] in self.__C_ships:
                            return 1
                if side == 'D':
                    if x - lung + 1 < 0:
                        return 1
                    for i in range(0,lung):
                        if [x-i,y] in self.__C_ships:
                            return 1
        
        
        return 2
        
    def generateShips(self):
        for i in range (2,5):
            
            gata = False
            while not gata:
                x = random.randint(0,8)
                y = random.randint(0,8)
                if self.validateShip(x, y, i, 'H', 'L', 'C') == 2:
                    ori = 'H'
                    side = 'L'
                    break
                if self.validateShip(x, y, i, 'H', 'R', 'C') == 2:
                    ori = 'H'
                    side = 'R'
                    break
                if self.validateShip(x, y, i, 'V', 'U', 'C') == 2:
                    ori = 'V'
                    side = 'U'
                    break
                if self.validateShip(x, y, i, 'V', 'D', 'C') == 2:
                    ori = 'V'
                    side = 'D'
                    break
                
            if ori == 'H':
                if side == 'L':
                    for j in range(0,i):
                        self.__C_ships.append([x,y+j])
                if side == 'R':
                    for j in range(0,i):
                        self.__C_ships.append([x,y-j])
            if ori == 'V':
                if side == 'U':
                    for j in range(0,i):
                        self.__C_ships.append([x+j,y])
                if side == 'D':
                    for j in range(0,i):
                        self.__C_ships.append([x-j,y])    
                        
        s = self.__str__('C')
        print(s)
        
    def generateTable(self):
        table = [None]*8
        for i in range (8):
            table[i] = ['~']*8
        return table
    
    def __str__(self, player):
        table = self.generateTable()
        
        
        if player == 'H':
            print("--------HUMAN--------")
            print(self.__H_ships)
            print(self.__H_hits)
            s = " |A|B|C|D|E|F|G|H|\n"
            
            for x in self.__H_ships:
                table[int(x[0])][int(x[1])] = '#'
                if x in self.__C_hits:
                    table[int(x[0])][int(x[1])] = 'X'
                
            for i in range(8):
                s+=str(i+1)
                for j in range(8):
                    s+="|"+table[i][j]
                s+="|\n"
            return s
        
        if player == 'C':
            print("--------COMPUTER--------")
            print(self.__C_ships)
            print(self.__C_hits)
            s = " |A|B|C|D|E|F|G|H|\n"
            
            for x in self.__C_ships:
                table[int(x[0])][int(x[1])] = '#'
                if x in self.__H_hits:
                    table[int(x[0])][int(x[1])] = 'X'
            
                    
            for i in range(8):
                s+=str(i+1)
                for j in range(8):
                    s+="|"+table[i][j]
                s+="|\n"
            return s