'''
Created on Feb 13, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
        
    def ui_start_game(self):
        
        print("Initiating the tables!")
        
        self.__controller.initiateGame()
        
        print("Start taking hits!")
        
        self.__controller.playGame()
        
        self.__controller.printTable('H')
        self.__controller.printTable('C')
    
        
    def __read_command(self):
        return input("Input option:")
    
    def print_all_options(self):
        print("1.Start game!")

    def run(self):
        while True:
            self.print_all_options()
            options = {1:self.ui_start_game()}
            op = int(input("Enter options: "))
            options[op]()
            if op == 0:
                return False
        