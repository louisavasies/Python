'''
Created on Feb 13, 2018

@author: Louis
'''

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
    def initiateGame(self):
        self.printTable('H')
        for i in range(2,5):
            print("Creating a battleship of length "+str(i))
            x = input("Enter x coordinate:")
            x = int(x)-1
            y = input("Enter y coordinate:")    
            y = ord(y)%32 - 1
            ori = input("Enter orientation:")
            side = input("Enter side:") 
            ans = self.__repo.addShip(x,y,i,ori,side)
            while ans != 1:
                ans = self.__repo.addShip(x,y,i,ori,side)
                if ans == 0:
                    print("Wrong coordinates! Try again!")
                    x = input("Enter x coordinate:")
                    x = int(x)-1
                    y = input("Enter y coordinate:") 
                    y = ord(y)%32 - 1
                    ans = self.__repo.addShip(x,y,i,ori,side)
                if ans == 1:
                    print("Battleship overlaps! Try again!")
                    print("Wrong coordinates! Try again!")
                    x = input("Enter x coordinate:")
                    x = int(x)-1
                    y = input("Enter y coordinate:")
                    y = ord(y)%32 - 1 
                    ans = self.__repo.addShip(x,y,i,ori,side)
            self.__repo.addShip(x,y,i,ori,side)
    
            
        self.__repo.generateShips()
        
            
    
    def checkShips(self):
        return self.__repo.checkShips('H') and self.__repo.checkShips('C')
    
    def addHitHuman(self,x,y):
        x = int(x)-1
        y = ord(y)%32-1
        ans = self.__repo.addHitHuman(x,y)
        while ans != 2:
            if ans == 0:
                print("Wrong coordinates! Try again!")    
                x = input("Enter x coordinate:")
                x = int(x)-1
                y = input("Enter y coordinate:") 
                y = ord(y)%32 - 1
                ans = self.__repo.addHitHuman(x,y)
            if ans == 1:
                print("Hit already made! Try again!")
                x = input("Enter x coordinate:")
                x = int(x)-1
                y = input("Enter y coordinate:") 
                y = ord(y)%32 - 1
                ans = self.__repo.addHitHuman(x,y)
    
    def playGame(self):
        
        Done = self.checkShips()
        
        
        while not Done:
            
            #Human
            print("Creating a hit:")
            x = input("Enter x coordinate:")
            y = input("Enter y coordinate:")
            self.addHitHuman(x, y)
            
            self.printTable('C')
            
            #Computer
            self.__repo.addHitComputer()
            
            self.printTable('H')
            
            Done = 1 - self.checkShips()
        
        print("GAME OVER!")
        return
            
    def printTable(self, player):
        s = self.__repo.__str__(player)
        print(s)
        