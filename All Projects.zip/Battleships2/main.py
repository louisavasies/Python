'''
Created on Feb 13, 2018

@author: Louis
'''

from ui.Console import Console
from controller.Controller import Controller
from repository.Repository import Repository



class App(object):
    def main(self):

        repo = Repository()
        contr = Controller(repo)

        cons = Console(contr)
        cons.run()



if __name__ == '__main__':
        app = App()
        app.main()
