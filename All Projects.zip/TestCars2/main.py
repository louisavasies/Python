'''
Created on Jan 19, 2018

@author: Louis
'''
from controller.Controller import Controller
from domain.Car import Car
from UI.Console import Console
from repository.Repository import CarFileRepository

class App(object):
    def main(self):
        car_repo = CarFileRepository("cars.txt", Car.strToCar, Car.carToStr)
        contrl = Controller(car_repo)

        cons = Console(contrl)
        cons.run()



if __name__ == '__main__':
    try:
        app = App()
        app.main()
    except Exception as ex:
        print("Exceptie in aplicatie: ", ex)
