'''
Created on Jan 19, 2018

@author: Louis
'''
import unittest

from domain.Car import Car

class TestCar(unittest.TestCase):


    def setUp(self):
        self._id = 1
        self._type = "A"
        self._brand = "BMW"
        self._eng_power = 286
        self._avg_speed = 260
        
        self._car = Car(self._id, self._type, self._brand, self._eng_power, self._avg_speed)
        
        self._otherid = 2
        self._anotherid = 3
        self._othertype = "B"
        self._anothertype = "C"
        self._other_eng_power = 272
        
        self._othercar = Car(self._otherid, self._othertype, self._brand, self._other_eng_power, self._avg_speed)
        self._anothercar = Car(self._anotherid, self._anothertype, self._brand, self._other_eng_power, self._avg_speed)


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._car.get_id(), 1)
        self.assertEqual(self._car.get_type(), "A")
        self.assertEqual(self._car.get_brand(), "BMW")
        self.assertEqual(self._car.get_eng_power(), 286)
        self.assertEqual(self._car.get_avg_speed(), 260)
        self.assertEqual(self._car.get_top_speed(), 74360)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()