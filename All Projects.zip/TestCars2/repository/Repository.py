'''
Created on Jan 19, 2018

@author: Louis
'''

from domain.Validator import StoreError
import operator

class Repository(object):
    def __init__(self):
        self._elems = []
        
        
        
        
    def add(self, elem):
        if elem in self._elems:
            raise RepositoryError("Car already exists!")
        if elem.get_id() <= 0:
            raise Exception("Id must be > 0")
        if elem.validate_type() == 0 or elem.validate_brand == 0:
            raise Exception("Wrong type or brand!")
        if elem.get_eng_power() < 50:
            raise Exception("Engine power must be >= 50")
        if elem.get_avg_speed() < 150:
            raise Exception("Average speed must be >= 150")
        self._elems.append(elem)
        
    def switch_engines(self, id1, id2):
        car1 = self.find_by_id(id1)
        car2 = self.find_by_id(id2)
        if (car1.get_type() == "A" and car2.get_type() == "C") or (car1.get_type() == "C" and car2.get_type() == "A"):
            raise Exception("Types are too different! Try A->B, B->A ")    
        if car1.get_brand() != car2.get_brand():
            raise Exception("Brands must be the same")
        aux = car1.get_eng_power()
        car1.set_eng_power(car2.get_eng_power())
        car2.set_eng_power(aux)
        print("Switching completed successfully")
        return self._elems
        
    
    def top5Cars(self):
        cars = []
        for car in self._elems:
            cars.append(car)
        cars.sort(key = lambda x: x.get_top_speed(), reverse = True)
        return cars
        
        
        
    def find_by_id(self, Id):
        for elem in self._elems:
            if elem.get_id() == Id:
                return elem
        raise RepositoryError("A car with such an Id was not found!")
    
    
    def find(self, elem):
        if not elem in self._elems:
            raise RepositoryError("Car is not in repo!")
        return self._elems[elem.get_id()]
    
    def size(self):
        return len(self._elems)


class RepositoryError(StoreError):
    pass

class CarFileRepository(Repository):
    def __init__(self, txt, str_to_car, car_to_str):
        self.__txt = txt
        self.__strToObj = str_to_car
        self.__objToStr = car_to_str
        Repository.__init__(self)
        self.__readAllFromFile()
    
    def __readAllFromFile(self):
        with open(self.__txt,"r") as f:
            for line in f.readlines():
                line = line.strip()
                if len(line)>0:
                    obj = self.__strToObj(line)
                    self._elems.append(obj)
    
    def __writeAllToFile(self):
        with open(self.__txt,"w") as f:
            for obj in self._elems:
                line = self.__objToStr(obj)
                f.write(line+"\n")
    
    def add(self, elem):
        Repository.add(self, elem)
        self.__writeAllToFile()


