'''
Created on Jan 19, 2018

@author: Louis
'''
import unittest
from domain.TestCar import TestCar
from repository.Repository import CarFileRepository
from domain.Car import Car


class TestRepository(unittest.TestCase):


    def setUp(self):
        TestCar.setUp(self)
        self._repo = CarFileRepository("cars.txt", Car.strToCar, Car.carToStr)
        


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._repo.size(), 0)
        self._repo.add(self._car)
        self._repo.add(self._othercar)
        self._repo.add(self._anothercar)
        self.assertEqual(self._repo.size(), 3)
        
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()