'''
Created on Feb 8, 2018

@author: Louis
'''

from ui.Console import Console
from controller.Controller import Controller
from repository.Repository import Repository



class App(object):
    def main(self):
        table = [None]*6
        for i in range (0,6):
            table[i] = ['-']*7
        repo = Repository(table)
        contr = Controller(repo)

        cons = Console(contr)
        cons.run()



if __name__ == '__main__':
        app = App()
        app.main()
