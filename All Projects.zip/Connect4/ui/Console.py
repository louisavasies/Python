'''
Created on Feb 8, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
        
    def ui_start_game(self):
        print(self.__controller.getTable())
        
        Done = 0
        
        while Done == 0:
            
            #Human
            
            
            ans = 1
            for i in range(0,6):
                for j in range(0,7):
                    ans = ans or self.__controller.isFree(i, j)
            
            if ans == 0:
                print("Players unable to move!")
                Done = 1
            
            c = input("Enter column:")
            print("\n\n")
            
            ans = self.__controller.placePieceH(c)
            if ans:
                print("Human placed on column "+ans+"\n")
            while ans == 0:
                print("Invalid move, try again:\n")
                c = input("Enter column:")
                ans = self.__controller.placePieceH(c)

            table = self.__controller.getTable()
            print(table)
            
            #Computer
            ans = 1
            for i in range(0,6):
                for j in range(0,7):
                    ans = ans or self.__controller.isFree(i, j)
            
            
            if ans == 0:
                print("Players unable to move!")
                Done = 1
                
            ans = self.__controller.placePieceC()
            if ans == 0:
                print("Computer unable to move!")
            ans = self.__controller.placePieceC()
            print("Computer placed on "+str(ans)+"\n")
            
            table = self.__controller.getTable()
            print(table)
            
            
            Done = 1 - ans
            
        print("Game over!")   
    
    
        
    def __read_command(self):
        return input("Input option:")
    
    def print_all_options(self):
        print("1.Start game!")

    def run(self):
        while True:
            self.print_all_options()
            options = {1:self.ui_start_game()}
            op = int(input("Enter options: "))
            options[op]()
            if op == 0:
                return False   