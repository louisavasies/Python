'''
Created on Feb 8, 2018

@author: Louis
'''

class Repository(object):
    def __init__(self, _table):
        self.__table = _table
        self.__L = [None] * 6
        self.__C = [None] * 7
        self.__D = [None] * 6
        
    def verifyRow(self):
        for i in range(0,5):
            for j in range (0,3):
                if self.isFree(i, j) and self.__table[i][j+1] == 'X' and self.__table[i][j+2] == 'X' and self.__table[i][j+3] == 'X':
                    self.placePiece(j, 'O')
                    return j 
            for j in range (3,6):
                if self.isFree(i, j) and self.__table[i][j-1] == 'X' and self.__table[i][j-2] == 'X' and self.__table[i][j-3] == 'X':
                    self.placePiece(j, 'O')
                    return j 
        return -1
    
    def verifyColumn(self):
        for c in range(0,6):
            for l in range(5, 2):
                if self.__table[l][c] == 'X' and self.__table[l-1][c] == 'X' and self.__table[l-2][c] == 'X' and self.isFree(l-3, c):
                    self.placePiece(c, 'O')
                    return c
            for l in range(2,0):
                if self.__table[l][c] == 'X' and self.__table[l+1][c] == 'X' and self.__table[l+2][c] == 'X' and self.isFree(l+3, c):
                    self.placePiece(c, 'O')
                    return c
    
    
    def validatePiece(self, c):
        if int(c) < 0 or int(c) > 6:
            return 0
        return 1
        
    def isFree(self, l, c):
        isFree = 1
        for i in range (l,0,-1):
            isFree = isFree and self.__table[i][int(c)] == '-'
        return isFree
    
    def placePiece(self, c, sign):
        for i in range(5,1,-1):
            if self.isFree(i, c) and self.validatePiece(c):
                self.__table[i][int(c)] = sign
                return c
        return 0
    
    def generateTable(self):
        table = [None]*6
        for i in range (0,6):
            table[i] = ['-']*7
        return table
    
    def __str__(self):
        s = "|0|1|2|3|4|5|6|\n"
        for i in range(0,6):
            for j in range (0,7):
                s+="|"+ self.__table[i][j]
            s+="|\n"
        return s
    
   