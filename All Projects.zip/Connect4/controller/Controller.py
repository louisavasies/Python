'''
Created on Feb 8, 2018

@author: Louis
'''
import random

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
    def isFree(self, l, c):
        return self.__repo.isFree(l, c)
        
    def placePieceH(self, c):
        sign = 'X'
        return self.__repo.placePiece(c, sign)
    
    def placePieceC(self):
        sign = 'O'
        ans = self.__repo.verifyRow()
        if ans:
            self.__repo.placePiece(ans, sign)
            return ans
        ans = self.__repo.verifyColumn()
        if ans:
            self.__repo.placePiece(ans, sign)
            return ans
        ans = 0
        while ans == 0:
            c = random.randint(0,6)
            ans = self.__repo.placePiece(c, sign)
            if ans:
                return self.__repo.placePiece(c, sign) 
        return 0
    
    def getTable(self):
        table = self.__repo.__str__()
        return table
