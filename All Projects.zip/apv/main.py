if __name__ == '__main__':
    
    for i in range (9, 33):
        for j in range(6, 21, 2):
            print(i, j, "0," )
    for i in range (11, 41):
        for j in range(22, 37, 2):
            print(i, j, "0,")
    for i in range (16, 45):
        for j in range(38, 53, 2):
            print(i, j, "0," )
    for i in range (21, 46):
        for j in range(54, 69, 2):
            print(i, j, "0," )
    for i in range (22, 47):
        for j in range(70, 85, 2):
            print(i, j, "0," )
    for i in range (27, 48):
        for j in range(86, 101, 2):
            print(i, j, "0," )
                    