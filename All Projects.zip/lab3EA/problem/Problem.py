'''
Created on Mar 24, 2018

@author: Louis
'''

class Problem(object):
    def __init__(self, filename):
        self.relationships = None
        self.now = 0
        self.total = 40
        self.unvisChildren = []
        self.filename = filename
        self.loadData(filename)
    
    def loadData(self, filename):
        self.relationships = [[0]*(self.total+1) for i in range(self.total+1)]
        with open(filename, 'r') as f:
            for line in f.readlines():
                line = line.strip()
                line = line.split(";")
                for item in range(1,len(line)):
                    self.relationships[line(1)][item] = 1
                
