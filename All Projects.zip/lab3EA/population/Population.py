'''
Created on Mar 24, 2018

@author: Louis
'''

class Population(object):
    def __init__(self, problem):
        self.problem = problem
        self.size = 0
        self.list = []
        
    def evaluate(self):
        for ind in self.list:
            ind.fitness(self.problem)
    
    def selection(self):
        if self.size < self.problem.total:
            self.problem.now = self.size
            self.list = sorted(self.list, key = lambda ind: ind.fitness(self.problem))
    
        