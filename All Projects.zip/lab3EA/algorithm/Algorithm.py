'''
Created on Mar 24, 2018

@author: Louis
'''

class Algorithm(object):
    def __init__(self, problem):
        self.problem = problem
        self.population = []   
             
    def iteration(self, population):
        self.problem.unvisChildren = sorted(self.problem.unvisChildren, key = lamdba ind : ind.fitness(self.problem))
        newUnvisChildren = []
        for x in self.problem.unvisChildren:
            while (len(x.conn)):
                if x.crossover() not in self.population:
                    self.population.append(x.crossover())
                    mutated = x.mutate()
                    for ind in mutated:
                        newUnvisChildren.append(ind)
        self.problem.unvisChildren = newUnvisChildren
        return self.population
                
    
    def run(self, nrOfIterations):
        
    
    def statistics(self):
        pass