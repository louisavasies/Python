'''
Created on Mar 24, 2018

@author: Louis
'''


class Individ(object):
    def __init__(self, cSize, vmin):
        self.size = cSize
        self.conn = []
        self.vmin = vmin

        
    
    def fitness(self, problem):
        if problem.now == problem.total:
            return 1
        else:
            return float((100*problem.now)/problem.total)
    
    def mutate(self, problem):
        mutated = []
        for child in self.conn:
            if child not in problem.now:
                problem.now.append(child)
                mutated.append(child)
        return mutated
    
    def crossover(self):
        ind = 0
        length = 0
        for x in self.conn:
            if len(x.conn) > length:
                length = len(x.conn)
                ind = x 
        return ind 
    
    