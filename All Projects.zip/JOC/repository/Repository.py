'''
Created on Feb 7, 2018

@author: Louis
'''
import random




class Repository(object):
    def __init__(self, _table):
        self.__table = _table
        self.__MH = []
        self.__MAI = []
        
    def isFree(self, x, y):
        if [x,y] in self.__MH:
            return 0
        if [x,y] in self.__MAI:
            return 0
        return 1    
        
    def validMove(self,x,y):
        if int(x) < 0 or int(x) > 2 or int(y) < 0 or int(y) > 2:
            return 0   
        return 1 
    
    def isLine(self):
        if [0,0] in self.__MH and [0,1] in self.__MH and [0,2] in self.__MH:
            return 1
        if [1,0] in self.__MH and [1,1] in self.__MH and [1,2] in self.__MH:
            return 1
        if [2,0] in self.__MH and [2,1] in self.__MH and [2,2] in self.__MH:
            return 1
        if [0,0] in self.__MH and [1,0] in self.__MH and [2,0] in self.__MH:
            return 1
        if [0,1] in self.__MH and [1,1] in self.__MH and [2,1] in self.__MH:
            return 1
        if [0,2] in self.__MH and [1,2] in self.__MH and [2,2] in self.__MH:
            return 1
        if [0,0] in self.__MH and [1,1] in self.__MH and [2,2] in self.__MH:
            return 1
        if [2,0] in self.__MH and [2,1] in self.__MH and [2,2] in self.__MH:
            return 1
        
        
        
        if [0,0] in self.__MAI and [0,1] in self.__MAI and [0,2] in self.__MAI:
            return 2
        if [1,0] in self.__MAI and [1,1] in self.__MAI and [1,2] in self.__MAI:
            return 2
        if [2,0] in self.__MAI and [2,1] in self.__MAI and [2,2] in self.__MAI:
            return 2
        if [0,0] in self.__MAI and [1,0] in self.__MAI and [2,0] in self.__MAI:
            return 2
        if [0,1] in self.__MAI and [1,1] in self.__MAI and [2,1] in self.__MAI:
            return 2
        if [0,2] in self.__MAI and [1,2] in self.__MAI and [2,2] in self.__MAI:
            return 2
        if [0,0] in self.__MAI and [1,1] in self.__MAI and [2,2] in self.__MAI:
            return 2
        if [2,0] in self.__MAI and [2,1] in self.__MAI and [2,2] in self.__MAI:
            return 2
        
        return 0
        
    def createMoveHuman(self, x, y):
        return [x,y]
    
    def createMoveAI(self):
        if [0,0] in self.__MH:
            if [0,1] in self.__MH:
                if [0,2] not in self.__MH: 
                    m = [0,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [0,2] in self.__MH:
                if [0,1] not in self.__MH:
                    m =  [0,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [1,0] in self.__MH:
                if [2,0] not in self.__MH: 
                    m =  [2,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,0] in self.__MH:
                if [1,0] not in self.__MH: 
                    m =  [1,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [1,1] in self.__MH:
                if [2,2] not in self.__MH: 
                    m =  [2,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,2] in self.__MH:
                if [1,1] not in self.__MH: 
                    m = [1,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [1,0] in self.__MH:
            if [1,1] in self.__MH:
                if [1,2] not in self.__MH: 
                    m =  [1,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [1,2] in self.__MH:
                if [1,1] not in self.__MH: 
                    m =  [1,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [2,0] in self.__MH:
            if [2,1] in self.__MH:
                if [2,2] not in self.__MH: 
                    m =  [2,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,2] in self.__MH:
                if [2,1] not in self.__MH: 
                    m =  [2,1]        
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [0,1] in self.__MH:
            if [1,1] in self.__MH:
                if [2,1] not in self.__MH: 
                    m =  [2,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,1] in self.__MH:
                if [1,1] not in self.__MH: 
                    m =  [1,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [0,2] in self.__MH:
            if [1,2] in self.__MH:
                if [2,2] not in self.__MH: 
                    m =  [2,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,2] in self.__MH:
                if [1,2] not in self.__MH:
                    m =  [1,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [2,0] in self.__MH:
            if [1,1] in self.__MH:
                if [0,2] not in self.__MH: 
                    m = [0,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [0,2] in self.__MH:
                if [1,1] not in self.__MH: 
                    m =  [1,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [0,2] in self.__MH:
            if [0,1] in self.__MH:
                if [0,0] not in self.__MH: 
                    m =  [0,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [0,0] in self.__MH:
                if [0,1] not in self.__MH: 
                    m =  [0,1]       
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [1,2] in self.__MH:
            if [1,1] in self.__MH:
                if [0,1] not in self.__MH: 
                    m =  [0,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [1,0] in self.__MH:
                if [1,1] not in self.__MH: 
                    m =  [1,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [2,2] in self.__MH:
            if [2,1] in self.__MH:
                if [2,0] not in self.__MH: 
                    m =  [2,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [2,0] in self.__MH:
                if [2,1] not in self.__MH: 
                    m =  [2,1]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [2,0] in self.__MH:
            if [1,0] in self.__MH:
                if [0,0] not in self.__MH: 
                    m =  [0,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [0,0] in self.__MH:
                if [1,0] not in self.__MH: 
                    m =  [1,0]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        if [2,2] in self.__MH:
            if [1,2] in self.__MH:
                if [0,2] not  in self.__MH: 
                    m = [0,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
            if [0,2] in self.__MH:
                if [1,2] not in self.__MH: 
                    m =  [1,2]
                    if self.isFree(int(m[0]), int(m[1])):
                        return m
        ans = 0
        while not ans:
            x = random.randint(0,2)
            y = random.randint(0,2)
            if self.isFree(x, y):
                ans = 1
                return [x,y]
            else:
                ans = 0
        
    def addMove(self,move,sign):
        if sign == 'X':
            self.__MH.append(move)
        elif sign == 'O':
            self.__MAI.append(move)
            
    def generateTable(self):
        table = [None]*3
        for i in range (0, 3):
            table[i] = ['-']*3
        return table
    
    def __str__(self):
        table = self.generateTable()
        for x in self.__MH:
            table[int(x[0])][int(x[1])] = 'X'
        for y in self.__MAI:
            table[int(y[0])][int(y[1])] = 'O'
        s = ""
        t = ""
        u = ""
        v = ""
        for j in range(0,3):
            t+=str(table[0][j])
            t+="|"
        for j in range(0,3):
            u+=str(table[1][j])
            u+="|"
        for j in range(0,3):
            v+=str(table[2][j])
            v+="|"
        s += "|"+t+"\n"+"|"+u+"\n"+"|"+v+"\n"
        return s
    
            
    