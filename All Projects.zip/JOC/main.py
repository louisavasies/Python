'''
Created on Feb 7, 2018

@author: Louis
'''

from ui.Console import Console
from controller.Controller import Controller
from repository.Repository import Repository



class App(object):
    def main(self):
        table = [None]*3
        for i in range (0, 3):
            table[i] = ['-']*3
        repo = Repository(table)
        contr = Controller(repo)

        cons = Console(contr)
        cons.run()



if __name__ == '__main__':
        app = App()
        app.main()
