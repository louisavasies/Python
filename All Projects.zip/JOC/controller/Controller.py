'''
Created on Feb 7, 2018

@author: Louis
'''

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
    def validMove(self, x,y):
        if self.__repo.validMove(x,y) == 0:
            return 0
        return 1
    
    def isLine(self):
        if self.__repo.isLine() == 1:
            return 1
        elif self.__repo.isLine() == 2:
            return 2
        return 0
        
    def moveHuman(self,x,y):
        if self.__repo.isFree(x,y):
            sign = 'X'
            move = self.__repo.createMoveHuman(x,y)
            self.__repo.addMove(move,sign)
            return 1
        return 0
        
    def moveAI(self):
        sign = 'O'
        move = self.__repo.createMoveAI()
        self.__repo.addMove(move,sign)
    
    def getTable(self):
        table = self.__repo.__str__()
        return table