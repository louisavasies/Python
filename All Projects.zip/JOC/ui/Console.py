'''
Created on Feb 7, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
    def __read_command(self):
        return input("Input option:")
    
    def print_all_options(self):
        print("1.Start game!")

    def run(self):
        while True:
            self.print_all_options()
            options = {1:self.ui_placement()}
            op = int(input("Enter options: "))
            options[op]()
            if op == 0:
                return False
            
    def ui_placement(self):
        print("Beginning placement phase!")
        for i in range(4):  # @UnusedVariable
            x = input("Enter x: ")
            y = input("Enter y: ")
            
            while not self.__controller.validMove(x,y):
                print("Invalid coordinates for the move, retry: \n")
                x = input("Enter x: ")
                y = input("Enter y: ")
                
            ans = self.__controller.moveHuman(x,y)
            
            while not ans: 
                print("Move already made, retry: \n")
                x = input("Enter x: ")
                y = input("Enter y: ")
                ans = self.__controller.moveHuman(x,y)
                
            print("\nHuman made move ["+x+","+y+"] \n")
            
            if self.__controller.isLine() == 1:
                print("Human won!")
                break
            
            self.__controller.moveAI()
            

            if self.__controller.isLine() == 2:
                print("Computer won!")
                break
                
            s = self.__controller.getTable()
            print(s)


        print("Placement phase done!")
        
        
                