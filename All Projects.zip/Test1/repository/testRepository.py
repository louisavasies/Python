'''
Created on Jan 16, 2018

@author: Louis
'''
import unittest
from repository.Repository import Repository, FileRepository
from domain.Car import Car


class Test(unittest.TestCase):


    def testRepository(self):
        self._repo = FileRepository("cars.txt", Car.strToCar, Car.carToStr)
        
        c1 = Car(1, 'A', 'BMW', 286, 260)
        c2 = Car(2, 'B', 'BMW', 300, 280)
        
        self._repo.add(c1)
        self._repo.add(c2)
        
        self._repo.swap_engines(1, 2)
        self.assertEqual(c1.get_eng_power(), 300)
        
        
        
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testRepository']
    unittest.main()