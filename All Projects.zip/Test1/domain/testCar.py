'''
Created on Jan 16, 2018

@author: Louis
'''
import unittest
from domain.Car import Car


class Test(unittest.TestCase):


    def testCar(self):
        id = 1
        type = 'A'
        brand = 'BMW'
        eng_power = 286
        avg_speed = 260
        top_speed = eng_power * avg_speed
        car = Car(id, type, brand, eng_power, avg_speed)
        self.assertEqual(car.get_id(), 1)
        self.assertEqual(car.get_type(), 'A')
        self.assertEqual(car.get_brand(), 'BMW')
        self.assertEqual(car.get_eng_power(), 286)
        self.assertEqual(car.get_avg_speed(), 260)

        self.assertEqual(car.validate_type(), 1)
        car.set_type('D')
        self.assertEqual(car.validate_type(), 0)
        
        self.assertEqual(car.validate_brand(), 1)
        car.set_brand('Alpha Romeo')
        self.assertEqual(car.validate_brand(), 0)
        
        
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()