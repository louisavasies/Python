'''
Created on Feb 7, 2018

@author: Louis
'''
import random




class Repository(object):
    def __init__(self, _free):
        self.__table = None
        self.__H = []
        self.__C = []
        self.__F = _free
        
    def setFree(self):
        s = []
        for i in range(0,6):
            for j in range(0,6):
                if [i,j] not in self.__H and [i,j] not in self.__C:
                    s.append([i,j])
        return s
        
    def writeToFile(self, filename):
        f = open(filename, "w")
        try: 
            for x in self.__H:
                s = "H" + ";" + str(x[0]) + ";" + str(x[1]) + "\n"
                f.write(s)
            for x in self.__C:
                s = "C" + ";" + str(x[0]) + ";" + str(x[1]) + "\n"
                f.write(s) 
            f.close()
        except Exception as e:
            print("An error occured -" + str(e))
            
            
    def readFile(self, filename):
        self.__H = []
        self.__C = []

        f = open(filename, "r")
        try:
            line = f.readline().strip()
            while len(line) > 0:
                line = line.split(";")
                if line[0] == 'H':
                    self.__H.append([int(line[1]), int(line[2])])
                if line[0] == 'C':
                    self.__C.append([int(line[1]), int(line[2])])                    
                line = f.readline().strip()
            f.close()
        except IOError as e:
            print("An error occured - " + str(e))
            raise e   
            
        self.__F = self.setFree()
        
    def getFree(self):
        return self.__F
    
       
    def addMove(self,move,sign):
        if sign == 'X':
            self.__H.append(move)
            self.__F.remove(move)
        else:
            self.__C.append(move)
            self.__F.remove(move)
                    
    def isFree(self, x, y):
        if [x,y] in self.getFree():
            return 1
        return 0
        
    def validateMove(self, x, y):
        x = int(x)
        y = int(y)
        
        if x == 0:
            if y == 0:
                return (self.isFree(x+1, y) and self.isFree(x+1, y+1) and self.isFree(x, y+1))
            if y == 5:
                return (self.isFree(x, y-1) and self.isFree(x+1, y-1) and self.isFree(x+1, y))
            if y > 0 and y < 5:
                return (self.isFree(x, y-1) and self.isFree(x+1, y-1) and self.isFree(x+1,y) and self.isFree(x+1, y+1) and self.isFree(x, y+1))
        if x == 5:
            if y == 0:
                return (self.isFree(x-1, y) and self.isFree(x-1, y+1) and self.isFree(x, y+1))
            if y == 5:
                return (self.isFree(x, y-1) and self.isFree(x-1, y-1) and self.isFree(x-1, y))
            if y > 0 and y < 5:
                return (self.isFree(x, y-1) and self.isFree(x-1, y-1) and self.isFree(x-1, y) and self.isFree(x-1, y+1) and self.isFree(x, y+1))
        if y == 0:
            if x > 0 and x < 5:
                return (self.isFree(x-1, y) and self.isFree(x-1, y+1) and self.isFree(x, y+1) and self.isFree(x+1, y+1) and self.isFree(x+1, y))
        if y == 5:
            if x > 0 and x < 5:
                return (self.isFree(x-1, y) and self.isFree(x-1, y-1) and self.isFree(x, y-1) and self.isFree(x+1, y-1) and self.isFree(x+1, y))
        return (self.isFree(x-1, y-1) and self.isFree(x, y-1) and self.isFree(x+1, y-1) and self.isFree(x+1, y) and self.isFree(x+1, y+1) and self.isFree(x, y+1) and self.isFree(x-1, y+1) and self.isFree(x-1, y))
        
        
        
            
    def createMoveC(self):
        ans = 0
        while ans == 0:
            x = random.randint(0,5)
            y = random.randint(0,5)
            if self.validateMove(x, y):
                if self.isFree(x, y):
                    ans = 1
                    return [x,y]
            ans = 0
            
            
    def generateTable(self):
        table = [None]*6
        for i in range (0,6):
            table[i] = ['-']*6
        return table
    
    def __str__(self):
        table = self.generateTable()
        for x in self.__H:
            table[int(x[0])][int(x[1])] = 'X'
        for x in self.__C:
            table[int(x[0])][int(x[1])] = 'O'
        s = " |0|1|2|3|4|5|\n"
        for i in range(6):
            s+=str(i)
            for j in range(6):
                s+="|"+table[i][j]
            s+="|\n"
        return s
        
    
    
    
        
        