'''
Created on Feb 7, 2018

@author: Louis
'''

from ui.Console import Console
from controller.Controller import Controller
from repository.Repository import Repository



class App(object):
    def main(self):
        s = []
        for i in range(0,6):
            for j in range(0,6):
                s.append([i,j])

        repo = Repository(s)
        contr = Controller(repo)

        cons = Console(contr)
        cons.run()



if __name__ == '__main__':
        app = App()
        app.main()
