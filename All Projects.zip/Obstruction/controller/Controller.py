'''
Created on Feb 7, 2018

@author: Louis
'''
from fileinput import filename

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
    def tryMove(self, x, y):
        return self.__repo.validateMove(x,y)
        
    def createH(self, x, y):
        if self.__repo.validateMove(x, y) == 0:
            return 0
        if self.__repo.isFree(x,y) == 0:
            return 1
        self.__repo.addMove([x,y],"X")
        return 2
        
    def createC(self):
        move = self.__repo.createMoveC()
        self.__repo.addMove(move,"O")
        return move
    
    def getFree(self):
        s = self.__repo.getFree()
        return s
    
    def save_game(self, filename):
        self.__repo.writeToFile(filename)
        
    def load_game(self, filename):
        self.__repo.readFile(filename)
    
    def printTable(self):
        table = self.__repo.__str__()
        print(table)