'''
Created on Feb 7, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
    def ui_start_game(self):
        Done = False
        
        self.__controller.printTable()
        
        
        while not Done:
            
            s = self.__controller.getFree()
            
            
            #Human
            
            res = 0
            for x in s:
                res = res or self.__controller.tryMove(int(x[0]), int(x[1])) 
                    
            if res == 0:
                print("Player unable to move --> Computer has won! \n")
            
            
            x=input("Enter x:")
            y=input("Enter y:")
            print("\n\n")
            ans = self.__controller.createH(int(x),int(y))
            if ans == 2:
                print("Human placed on ["+x+","+y+"]\n")

            while ans != 2:
                if ans == 0:
                    print("Invalid move, try again:\n")
                elif ans == 1:
                    print("Move not free, try again:\n")
                x=input("Enter x:")
                y=input("Enter y:")
                ans = self.__controller.createH(x,y)
                
                    
                
                
            self.__controller.printTable()   
                
                
                
            #Computer
            
            
            res = 0
            
            for x in s:
                res = res or self.__controller.tryMove(x[0],x[1])
                    
            if res == 0:
                print("Computer unable to move --> Player has won!")
                
            move = self.__controller.createC()
            print("Computer placed on "+str(move)+"\n")
            
            self.__controller.printTable()
            

            
            Done = 1 - res
            
            
            print("\n\n")
            print("1.Load game!")
            print("2.Save game!")
            print("0.Continue!")
            
            options = {"1":self.ui_load_game,"2":self.ui_save_game,"0":self.ui_start_game}
            op = input("Enter command: ")
            print("\n\n")
            
            options[op]()
            print("\n\n")
            
        print("Game Over!")   
            
        
    def run(self):
        while True:
            self.print_all_options()
            print("\n\n")
            options = {"1":self.ui_start_game,"2":self.ui_load_game,"3":self.ui_save_game}
            op = self.__read_command()
            options[op]()
            if op == 0:
                return False   
            
    def ui_load_game(self):
        filename = 'obs.txt'
        self.__controller.load_game(filename)
        print("Game loaded!")
        self.ui_start_game()
        
    def ui_save_game(self):
        filename = 'obs.txt'
        self.__controller.save_game(filename)
        print("Game saved! Continue? ")
        ans = input("Answer with Y or N!")  
        if ans == "Y":
            self.ui_start_game()
        else:
            return       
     
    def __read_command(self):
        return input("Input option:")
    
    def print_all_options(self):
        print("1.Start game!")
        print("2.Load game!")
        print("3.Save game!")