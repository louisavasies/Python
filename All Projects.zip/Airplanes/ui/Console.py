'''
Created on Feb 12, 2018

@author: Louis
'''

class Console(object):
    def __init__(self, _controller):
        self.__controller = _controller
        
        
        
        
    def ui_start_game(self):
        Done = False
        
        #Human
        self.__controller.printTable('H')
        for i in range(2):  # @UnusedVariable
            gata = False
            while not gata:
                x=input("Enter x:")
                y=input("Enter y:")
                ori=input("Enter orientation:")
                side=input("Enter side:")
                gata = self.__controller.addPlaneH(x,y,ori,side)
                self.__controller.printTable('H')  
        
        self.__controller.printTable('H')
        
        #Computer
        self.__controller.addPlaneC()
        self.__controller.printTable('C')
        
        
        #playing
        while not Done:
            #Human
            x=input("Enter x:")
            y=input("Enter y:")
            ans = self.__controller.addLovitura(x,y)
            while ans != 2:
                x=input("Enter x:")
                y=input("Enter y:")
                ans = self.__controller.addLovitura(x,y)
 
            print("-----COMPUTER'S TABLE-----")
            self.__controller.printTable('C')
            
            #Computer
            self.__controller.addLovituraC()
            
            print("-----HUMAN'S TABLE-----")
            self.__controller.printTable('H')
            
            Done = 1 - self.__controller.checkPlanes()
        
        self.__controller.checkPlanes()
        self.__controller.printTable('C')
        self.__controller.printTable('H')
        
        print("Game over!")
        return
    
        
                
        
    def __read_command(self):
        return input("Input option:")
    
    def print_all_options(self):
        print("1.Start game!")

    def run(self):
        while True:
            self.print_all_options()
            options = {1:self.ui_start_game()}
            op = int(input("Enter options: "))
            options[op]()
            if op == 0:
                return False   
        