'''
Created on Feb 12, 2018

@author: Louis
'''

class Controller(object):
    def __init__(self, _repo):
        self.__repo = _repo
        
    def checkPlanes(self):
        return self.__repo.checkPlanes('H') and self.__repo.checkPlanes('C')
        
    def addPlaneH(self,x,y,ori,side):
        y = ord(y)%32-1
        if self.__repo.addPlane(x,y,ori,side):
            print("Avion adaugat!\n")
            return 1
        print("Avion neadaugat, reincearca!\n")
        return 0
    
    def addPlaneC(self):
        self.__repo.genPlanes()
        
    def addLovitura(self,x,y):
        if y is int:
            print("Y coordinate must be a literal A-H")
            return 0
        y = ord(y)%32-1
        ans = self.__repo.addLovitura(x,y)
        if ans == 0:
            print("Coordonate nevalide!\n")
            return 0
        if ans == 1:
            print("Lovitura deja existenta!")
            return 0
        if ans == 2:
            print("Lovitura adaugata!")
            return 2
        
    def addLovituraC(self):
        return self.__repo.addLovituraC()
        
        
    def printTable(self, player):
        table = self.__repo.__str__(player)
        print(table)
        print("\n---------------------------\n")        
        
        
        
        
        
        
        
        