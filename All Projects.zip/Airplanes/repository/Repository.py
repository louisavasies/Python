'''
Created on Feb 12, 2018

@author: Louis
'''
import random

class Repository(object):
    def __init__(self):
        self.__C = []
        self.__H = []
        self.__C_heads = []
        self.__H_heads = []
        self.__C_l = []
        self.__H_l = []
        
        
    def addLovituraC(self):
        ans = 0
        for x in self.__C_l:
            if x in self.__H:
                ans = 1
                ind = random.randint(0, len(self.__C_l)-1)
                break
            
        if ans == 0:
            x = random.randint(0,7)
            y = random.randint(0,7)
            self.__C_l.append([x,y])
            return 1
        
        Done = False
        while Done == False:
            lov = self.__C_l[ind]
            Done = self.addLovituraForC(lov[0]+random.randint(-2,3), lov[1]+random.randint(-2,3))
            print(Done)
        return 1
    
    
    def checkPlanes(self, player):
        if player == 'H':
            if len(self.__H_heads) == 0:
                return 0
            inc = 0
            for x in self.__H_heads:
                if x in self.__C_l:
                    for i in range(inc, inc + 10):
                        self.__C_l.append(self.__H[i])
                    self.__H_heads.remove(x)
                inc+=10
        if player == 'C':
            if len(self.__C_heads) == 0:
                return 0
            inc = 0
            for x in self.__C_heads:
                if x in self.__H_l:
                    for i in range(inc, inc + 10):
                        self.__H_l.append(self.__C[i])
                    self.__C_heads.remove(x)
                inc+=10
        return 1       
        
    def addLovituraForC(self,x,y):
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        if [x,y] in self.__C_l:
            return 0
        self.__C_l.append([x,y])
        self.checkPlanes('H')
        self.checkPlanes('C')
        return 1
        
    def addLovitura(self,x,y):
        x=int(x)
        y=int(y)
        if x < 0 or x > 7 or y < 0 or y > 7:
            return 0
        if [x,y] in self.__H_l:
            return 1
        self.__H_l.append([x,y])
        self.checkPlanes('C')
        self.checkPlanes('H')
        return 2    
        
    def genPlanes(self):
        for x in range(2):
            valid = 0
            while valid == 0:
                x = random.randint(0,8)
                y = random.randint(0,8)
                if self.validatePlane(x, y, 'H', 'UP','C'):
                    ori = 'H'
                    side = 'UP'
                    break
                if self.validatePlane(x, y, 'H', 'DOWN','C'):
                    ori = 'H'
                    side = 'DOWN'
                    break
                if self.validatePlane(x, y, 'V', 'RIGHT','C'):
                    ori = 'V'
                    side = 'RIGHT'
                    break
                if self.validatePlane(x, y, 'V', 'LEFT','C'):
                    ori = 'V'
                    side = 'LEFT'
                    break
            self.__C.append([x,y])
            self.__C_heads.append([x,y])
            if ori == 'H':
                if side == 'UP':
                    self.__C.append([x+1,y-2])
                    self.__C.append([x+1,y-1])
                    self.__C.append([x+1,y])
                    self.__C.append([x+1,y+1])
                    self.__C.append([x+1,y+2])
                    self.__C.append([x+2,y])
                    self.__C.append([x+3,y-1])
                    self.__C.append([x+3,y])
                    self.__C.append([x+3,y+1])
                    
                if side == 'DOWN':
                    self.__C.append([x-1,y-2])
                    self.__C.append([x-1,y-1])
                    self.__C.append([x-1,y])
                    self.__C.append([x-1,y+1])
                    self.__C.append([x-1,y+2])
                    self.__C.append([x-2,y])
                    self.__C.append([x-3,y-1])
                    self.__C.append([x-3,y])
                    self.__C.append([x-3,y+1])
                    
            if ori == 'V':
                if side == 'RIGHT':
                    self.__C.append([x-2,y-1])
                    self.__C.append([x-1,y-1])
                    self.__C.append([x,y-1])
                    self.__C.append([x+1,y-1])
                    self.__C.append([x+2,y-1])
                    self.__C.append([x,y-2])
                    self.__C.append([x-1,y-3])
                    self.__C.append([x,y-3])
                    self.__C.append([x+1,y-3])
                    
                if side == 'LEFT':
                    self.__C.append([x-2,y+1])
                    self.__C.append([x-1,y+1])
                    self.__C.append([x,y+1])
                    self.__C.append([x+1,y+1])
                    self.__C.append([x+2,y+1])
                    self.__C.append([x,y+2])
                    self.__C.append([x-1,y+3])
                    self.__C.append([x,y+3])
                    self.__C.append([x+1,y+3])
        
       
    def addPlane(self,x,y,ori,side):
        x=int(x)
        y=int(y)
        if self.validatePlane(x, y, ori, side,'H'):
            self.__H_heads.append([x,y])
            self.__H.append([x,y])
            if ori == 'H':
                if side == 'UP':
                    self.__H.append([x+1,y-2])
                    self.__H.append([x+1,y-1])
                    self.__H.append([x+1,y])
                    self.__H.append([x+1,y+1])
                    self.__H.append([x+1,y+2])
                    self.__H.append([x+2,y])
                    self.__H.append([x+3,y-1])
                    self.__H.append([x+3,y])
                    self.__H.append([x+3,y+1])
                if side == 'DOWN':
                    self.__H.append([x-1,y-2])
                    self.__H.append([x-1,y-1])
                    self.__H.append([x-1,y])
                    self.__H.append([x-1,y+1])
                    self.__H.append([x-1,y+2])
                    self.__H.append([x-2,y])
                    self.__H.append([x-3,y-1])
                    self.__H.append([x-3,y])
                    self.__H.append([x-3,y+1])
            if ori == 'V':
                if side == 'RIGHT':
                    self.__H.append([x-2,y-1])
                    self.__H.append([x-1,y-1])
                    self.__H.append([x,y-1])
                    self.__H.append([x+1,y-1])
                    self.__H.append([x+2,y-1])
                    self.__H.append([x,y-2])
                    self.__H.append([x-1,y-3])
                    self.__H.append([x,y-3])
                    self.__H.append([x+1,y-3])
                if side == 'LEFT':
                    self.__H.append([x-2,y+1])
                    self.__H.append([x-1,y+1])
                    self.__H.append([x,y+1])
                    self.__H.append([x+1,y+1])
                    self.__H.append([x+2,y+1])
                    self.__H.append([x,y+2])
                    self.__H.append([x-1,y+3])
                    self.__H.append([x,y+3])
                    self.__H.append([x+1,y+3])
            return 1
        return 0
            
    def validatePlane(self,x,y,ori,side,player):
        x=int(x)
        y=int(y)
        if player == 'H':
            if x < 0 or x > 7 or y < 0 or y > 7:
                return 0
            if ori == 'H':
                if side == 'UP':
                    if y-2 < 0 or y+2 > 7:
                        return 0
                    if x+3 > 7:
                        return 0
                    if [x,y] in self.__H or [x+1,y-2] in self.__H or [x+1,y-1] in self.__H or [x+1,y] in self.__H or [x+1,y+1] in self.__H or [x+1,y+2] in self.__H or [x+2,y] in self.__H or [x+3,y-1] in self.__H or [x+3,y] in self.__H or [x+3,y+1] in self.__H:
                        return 0
                if side == 'DOWN':
                    if y-2 < 0 or y+2 > 7:
                        return 0
                    if x-3 < 0:
                        return 0
                    if [x,y] in self.__H or [x-1,y-2] in self.__H or [x-1,y-1] in self.__H or [x-1,y] in self.__H or [x-1,y+1] in self.__H or [x-1,y+2] in self.__H or [x-2,y] in self.__H or [x-3,y-1] in self.__H or [x-3,y] in self.__H or [x-3,y+1] in self.__H:
                        return 0
            if ori == 'V':
                if side == 'RIGHT':
                    if x-2 < 0 or x+2 > 7:
                        return 0
                    if y-3 < 0:
                        return 0
                    if [x,y] in self.__H or [x-2,y-1] in self.__H or [x-1,y-1] in self.__H or [x,y-1] in self.__H or [x+1,y-1] in self.__H or [x+2,y-1] in self.__H or [x+2,y] in self.__H or [x-1,y-3] in self.__H or [x,y-3] in self.__H or [x+1,y-3] in self.__H in self.__H:
                        return 0
                if side == 'LEFT':
                    if x-2 < 0 or x+2 > 7:
                        return 0
                    if y+3 > 7:
                        return 0
                    if [x,y] in self.__H or [x-2,y+1] in self.__H or [x-1,y+1] in self.__H or [x,y+1] in self.__H or [x+1,y+1] in self.__H or [x+2,y+1]  in self.__H or [x+2,y] in self.__H or [x-1,y+3] in self.__H or [x,y+3] in self.__H or [x+1,y+3] in self.__H in self.__H:
                        return 0
        if player == 'C':
            if x < 0 or x > 7 or y < 0 or y > 7:
                return 0
            if ori == 'H':
                if side == 'UP':
                    if y-2 < 0 or y+2 > 7:
                        return 0
                    if x+3 > 7:
                        return 0
                    if [x,y] in self.__C or [x+1,y-2] in self.__C or [x+1,y-1] in self.__C or [x+1,y] in self.__C or [x+1,y+1] in self.__C or [x+1,y+2] in self.__C or [x+2,y] in self.__C or [x+3,y-1] in self.__C or [x+3,y] in self.__C or [x+3,y+1] in self.__C:
                        return 0
                if side == 'DOWN':
                    if y-2 < 0 or y+2 > 7:
                        return 0
                    if x-3 < 0:
                        return 0
                    if [x,y] in self.__C or [x-1,y-2] in self.__C or [x-1,y-1] in self.__C or [x-1,y]  in self.__C or [x-1,y+1] in self.__C or [x-1,y+2] in self.__C or [x-2,y] in self.__C or [x-3,y-1] in self.__C or [x-3,y] in self.__C or [x-3,y+1] in self.__C:
                        return 0
            if ori == 'V':
                if side == 'RIGHT':
                    if x-2 < 0 or x+2 > 7:
                        return 0
                    if y-3 < 0:
                        return 0
                    if [x,y] in self.__C or [x-2,y-1] in self.__C or [x-1,y-1]  in self.__C or [x,y-1] in self.__C or [x+1,y-1] in self.__C or [x+2,y-1] in self.__C or [x+2,y] in self.__C or [x-1,y-3] in self.__C or [x,y-3] in self.__C or [x+1,y-3] in self.__C:
                        return 0
                if side == 'LEFT':
                    if x-2 < 0 or x+2 > 7:
                        return 0
                    if y+3 > 7:
                        return 0
                    if [x,y] in self.__C or [x-2,y+1] in self.__C or [x-1,y+1] in self.__C or [x,y+1] in self.__C or [x+1,y+1] in self.__C or [x+2,y+1] in self.__C or [x+2,y] in self.__C or [x-1,y+3] in self.__C or [x,y+3] in self.__C or [x+1,y+3] in self.__C:
                        return 0
        
        return 1
    
    
    def generateTable(self):
        table = [None]*8
        for i in range (8):
            table[i] = ['~']*8
        return table
    
    def __str__(self, player):
        table = self.generateTable()
        
        
        if player == 'H':
            s = " |A|B|C|D|E|F|G|H|\n"
            for x in self.__H:
                table[int(x[0])][int(x[1])] = '#'
            for x in self.__C_l:
                table[int(x[0])][int(x[1])] = 'X'
            for x in self.__H_heads:
                if x in self.__C_l:
                    table[int(x[0])][int(x[1])] = 'X'
                
                
            for i in range(8):
                s+=str(i)
                for j in range(8):
                    s+="|"+table[i][j]
                s+="|\n"
            return s
        
        if player == 'C':
            s = " |A|B|C|D|E|F|G|H|\n"
            for x in self.__H_l:
                table[int(x[0])][int(x[1])] = '*'
                if [int(x[0]),int(x[1])] in self.__C:
                    table[int(x[0])][int(x[1])] = 'X'
               
            for x in self.__H_l:
                table[int(x[0])][int(x[1])] = 'X'
                    
            for i in range(8):
                s+=str(i)
                for j in range(8):
                    s+="|"+table[i][j]
                s+="|\n"
            return s
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    