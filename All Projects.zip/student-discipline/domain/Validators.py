'''
Created on Jan 18, 2018

@author: Louis
'''

class StoreError(Exception):
    def __init__(self, message=None, ex=None):
        Exception.__init__(self, message)
        self.__ex = ex
        self.__message = message
    
    @property
    def message(self):
        msg = self.__message if self.__message else ""
        if self.__ex is None:
            return msg
        msg = msg + " " + type(self.__ex).__name__ + ": " + str(self.__ex)
        return msg
     
    def __str__(self):
        return self.message

class ValidatorError(StoreError):
    pass

class StudentValidator(object):
    def validate(self, st):
        errors = []
        if not type(st._id) is int or st._id <= 0:
            errors.append("Student Id must be an int greater or equal to 1")
        if not st._name:
            errors.append("Name must be a non-empty string")
       
        if len(errors) > 0:
            raise ValidatorError(str(errors)) 

class DisciplineValidator(object):
    def validate(self, di):
        errors = []
        if not type(di._id) is int or di._id<= 0:
            errors.append("Discipline Id must be an int greater or equal to 1")
        if not di._name:
            errors.append("Discipline name must be a non-empty string")

        if len(errors) > 0:
            raise ValidatorError(str(errors)) 
        
class StudentDisciplineValidator(object):
    def validate(self,st_di):
        errors = []
        if not type(st_di._id()) is int or st_di._id() < 0:
            errors.append("Student-Discipline id must be an int greater or equal to 1")
        if not type(st_di._sid()) is int and not type(st_di.get_sid()) < 0:
            errors.append("Student Id must be an int greater or equal to 1")
        if st_di.get_did() < 0 and not type(st_di.get_did()) is int:
            errors.append("Discipline Id must be an int greater or equal to 1")
        if st_di.get_grade() < 0 or st_di.get_grade() > 10:
            errors.append("Nota trebuie sa fie in intervalul [0,10]")
            
        if len(errors)>0:
            raise ValidatorError(str(errors))
