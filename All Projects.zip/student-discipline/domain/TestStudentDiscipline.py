'''
Created on Jan 18, 2018

@author: Louis
'''
import unittest
from domain.entities import StudentDisciplineDTO


class TestStudentDiscipline(unittest.TestCase):


    def setUp(self):
        self._sid = 1
        self._did = 1
        self._grade = 10
        self._SD = StudentDisciplineDTO(self._sid, self._did, self._grade)


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._SD.get_sid(), 1)
        self.assertEqual(self._SD.get_did(), 1)
        self.assertEqual(self._SD.get_grade(), 10)
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()