'''
Created on Jan 18, 2018

@author: Louis
'''

from domain.entities import StudentDisciplineDTO

class StudentDisciplineAssembler(object):
    
    @staticmethod
    def create_student_discipline_dto(Id, student, discipline, grade):
        return StudentDisciplineDTO(Id, student.get_id(), discipline.get_id(), grade )
    

    