'''
Created on Jan 18, 2018

@author: Louis
'''


class Student(object):
    def __init__(self, _id, _name):
        self.__id = _id
        self.__name = _name

    def get_id(self):
        return self.__id


    def get_name(self):
        return self.__name


    def set_name(self, value):
        self.__name = value
        
    def __str__(self):
        return str(self._id) + "||" + self._name



    
    



class Discipline(object):
    
    
    def __init__(self, _id, _name):
        self.__id = _id
        self.__name = _name

    def get_id(self):
        return self.__id


    def get_name(self):
        return self.__name


    def get_id(self):
        return self.__id


    def get_name(self):
        return self.__name


    def set_id(self, value):
        self.__id = value


    def set_name(self, value):
        self.__name = value


    def set_id(self, value):
        self.__id = value


    def set_name(self, value):
        self.__name = value


    def del_id(self):
        del self.__id


    def del_name(self):
        del self.__name


    def del_id(self):
        del self.__id


    def del_name(self):
        del self.__name


    def get_id(self):
        return self.__id


    def get_name(self):
        return self.__name


    def set_name(self, value):
        self.__name = value

    
    def __str__(self):
        return str(self._id) + "||" + self._name
    id = property(get_id, set_id, del_id, "id's docstring")
    name = property(get_name, set_name, del_name, "name's docstring")
    id = property(get_id, set_id, del_id, "id's docstring")
    name = property(get_name, set_name, del_name, "name's docstring")


    



class Grade(object):
    
    def __init__(self, _sid, _did, _grade):
        self.__sid = _sid
        self.__did = _did
        self.__grade = _grade

    def get_sid(self):
        return self.__sid


    def get_did(self):
        return self.__did


    def get_grade(self):
        return self.__grade


    def set_grade(self, value):
        self.__grade = value

    
    def __str__(self):
        return str(self._sid) + "||" +  str(self._sid) +  "||" + str(self._grade)
    
class StudentDisciplineDTO(object):
    def __init__(self, Id, sid, did, grade):
        self.__id = Id
        self.__sid = sid
        self.__did = did
        self.__grade = grade

    def get_id(self):
        return self.__id


    def get_sid(self):
        return self.__sid


    def get_did(self):
        return self.__did


    def get_grade(self):
        return self.__grade


    def set_sid(self, value):
        self.__sid = value


    def set_did(self, value):
        self.__did = value


    def set_grade(self, value):
        self.__grade = value


    
        
    
    def __str__(self):
        return str(self._id) + "||" + self._student_name + "||" + self._discipline_name + "||" + str(self._grade)


