'''
Created on Jan 18, 2018

@author: Louis
'''
import unittest
from domain.TestStudent import TestStudent
from domain.TestDiscipline import TestDiscipline
from domain.TestStudentDiscipline import TestStudentDiscipline
from domain.dto import StudentDisciplineDTO


class TestSDdto(unittest.TestCase):


    def setUp(self):
        TestStudent.setUp(self)
        TestDiscipline.setUp(self)
        TestStudentDiscipline.setUp(self)
        
        self._SDdto = StudentDisciplineDTO(1, self._student1.get_name(), self._discipline.get_name(), 10)

    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._SDdto.get_id(), 1)
        self.assertEqual(self._SDdto.get_student_name(), "Louisa Vasies")
        self.assertEqual(self._SDdto.get_discipline_name(), "FP")
        self.assertEqual(self._SDdto.get_grade(), 10)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()