'''
Created on Jan 18, 2018

@author: Louis
'''
import unittest
from domain.entities import Discipline

class TestDiscipline(unittest.TestCase):


    def setUp(self):
        self._id = 1
        self._name = "FP"
        self._discipline = Discipline(self._id, self._name)


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._discipline.get_id(),1)
        self.assertEqual(self._discipline.get_name(),"FP")
        self._discipline.set_name("Logica")
        self.assertEqual(self._discipline.get_name(),"Logica")
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()