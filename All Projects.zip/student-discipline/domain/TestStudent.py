'''
Created on Jan 18, 2018

@author: Louis
'''
import unittest
from domain.entities import Student

class TestStudent(unittest.TestCase):


    def setUp(self):
        self._id = 1
        self._name = "Louisa Vasies"
        self._student1 = Student(self._id, self._name)
        
    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._student1.get_id(), 1)
        self.assertEqual(self._student1.get_name(), "Louisa Vasies")
        self._student1.set_name("Bot")
        self.assertEqual(self._student1.get_name(), "Bot")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()