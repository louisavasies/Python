'''
Created on Mar 10, 2018

@author: Louis
'''
from problem.Problem import Problem
from controller.Controller import Controller
from ui.Console import Console

if __name__ == '__main__':
    p = Problem("ex1.txt", 4, 2, [[2,4,1,3],[1,3,2,4],[3,1,4,2],[4,2,3,1]])
    p.readFromFile()
    ctrl = Controller(p)
    ui = Console(ctrl)
    ui.run()