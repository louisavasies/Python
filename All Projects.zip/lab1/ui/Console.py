'''
Created on Mar 10, 2018

@author: Louis
'''

from problem.Problem import Problem

class Console(object):
    def __init__(self,ctrl):
        self.ctrl = ctrl
    
    def printMainMenu(self):
        print("1. BFS")
        print("2. GBFS")
        print("3.Change sudoku type")
        print("x. Exit")
        
    def run(self):
        while True:
            self.printMainMenu()
            op = input("Input command: ")
            if op == "x":
                return
            elif op == "1":
                print("BFS: The road is: \n")
                path = self.ctrl.bfs(self)
                for x in path:
                    print(x)
                print("")
            elif op == "2":
                print("GBFS: The road is: \n")
                path = self.ctrl.gbfs(self)
                for x in path:
                    print(x)
                print("")
            elif op == "3":
                print("1. 4x4")
                print("2. 6x6")
                print("3. 9x9")
                print("")
                opp = input("Enter change: ")
                if opp == "1":
                    p = Problem("ex1.txt", 4, 2, [[2,4,1,3],[1,3,2,4],[3,1,4,2],[4,2,3,1]])
                    p.readFromFile()
                    self.ctrl.problem = p
                elif opp == "2":
                    p = Problem("ex2.txt", 6, 2, [[1,4,3,5,2,6],[2,5,6,4,3,1],[6,2,4,3,1,5],[5,3,1,2,6,4],[3,6,5,1,4,2],[4,1,2,6,5,3]])
                    p.readFromFile()
                    self.ctrl.problem = p
                elif opp == "3":
                    p = Problem("ex3.txt", 9, 3, [[7,1,6,3,5,4,9,8,2],[5,3,9,8,2,1,7,6,4],[8,2,4,7,6,9,3,1,5],[1,8,2,4,3,6,5,7,9],[9,5,7,2,1,8,4,3,6],[6,4,3,5,9,7,8,2,1],[2,7,8,6,4,5,1,9,3],[3,9,5,1,7,2,6,4,8],[4,6,1,9,8,3,2,5,7]])
                    p.readFromFile()
                    self.ctrl.problem = p
                print("")
            else:
                print("Wrong command")
        