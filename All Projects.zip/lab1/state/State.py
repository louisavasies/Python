'''
Created on Mar 10, 2018

@author: Louis
'''
import copy

class State(object):
    def __init__(self, config):
        self.config = config

        
    def getState(self):
        return self.config
    
    def __eq__(self, other):
        return self.getState() == other.getState()
    
    def getPossible(self, row, column, value):
        new_state = copy.deepcopy(self.config)
        new_state[row][column] = value
        return new_state        
    
    def getValues(self, values, used):
        return [value for value in values if value not in used]
    
    def __str__(self):
        s = ""
        for i in range(0, len(self.config)):
            for j in range(0, len(self.config)):
                s+=int(self.config[i][j])+"|"
            s+="/n"
        return s    