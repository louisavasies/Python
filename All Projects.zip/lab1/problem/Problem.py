'''
Created on Mar 10, 2018

@author: Louis
'''
from state.State import State
from _sqlite3 import Row


class Problem(object):
    def __init__(self, filename, type, height, finalState):
        self.type = type
        self.height = height
        self.initState = State(0)
        self.finalState = finalState
        self.filename = filename
        
    def getInitialState(self):
        return self.initState

    def getFinalState(self):
        return self.finalState
        
    #Function for returning the set of valid numbers that can be used
    def getValues(self, values, used):
        return [value for value in values if value not in used]
    
    #Function for returning the first empty cell on the grid
    def get_cell(self, state):
        for row in range(0,self.type):
            for column in range(0,self.type):
                if state[row][column]  == 0:
                    numbers = range(1, self.type+1) #search space for a cell
                    in_column = [] #list of valid values in a cell's column
                    in_block = [] #list of valid values in a cell's block
                    
                    in_row = [number for number in state[row] if (number != 0)]
                    options = self.getValues(numbers, in_row) #get the valid values based on the row
                    
                    for column_index in range(self.type):
                        if state[column_index][column] != 0:
                            in_column.append(state[column_index][column])
                    options = self.getValues(options, in_column) #get the valid values based on the row + on the column
                    
                    row_start = int(row/self.height)*self.height
                    column_start = int(column/self.height)*self.height
                    
                    for block_row in range(0, self.height):
                        for block_column in range(0, self.height):
                            in_block.append(state[row_start + block_row][column_start + block_column])
                    options = self.getValues(options, in_block) #get the valid values based on row+column+block


                    return row, column, options
                    
        
    def expand(self, state):
        now = []
        row, column, options = self.get_cell(state) #optimal position to be filled
        for x in options:
            state1 = State(state)
            now.append(state1.getPossible(row, column, x))
        return now
    
    def expand_gbfs(self, state):
        now = []
        row, column, options = self.heuristic(state) #optimal position to be filled
        for x in options:
            state1 = State(state)
            now.append(state1.getPossible(row, column, x))
        return now
            
    def heuristic(self, state):
        minimum = 10
        for row in range(0,self.type):
            for column in range(0,self.type):
                if state[row][column]  == 0:
                    numbers = range(1, self.type+1) #search space for a cell
                    in_column = [] #list of valid values in a cell's column
                    in_block = [] #list of valid values in a cell's block
                    
                    in_row = [number for number in state[row] if (number != 0)]
                    options = self.getValues(numbers, in_row) #get the valid values based on the row
                    
                    for column_index in range(self.type):
                        if state[column_index][column] != 0:
                            in_column.append(state[column_index][column])
                    options = self.getValues(options, in_column) #get the valid values based on the row + on the column
                    
                    row_start = int(row/self.height)*self.height
                    column_start = int(column/self.height)*self.height
                    
                    for block_row in range(0, self.height):
                        for block_column in range(0, self.height):
                            in_block.append(state[row_start + block_row][column_start + block_column])
                    options = self.getValues(options, in_block) #get the valid values based on row+column+block


                    if len(options) < minimum:
                        minimum = len(options)
                        rowG = row
                        columnG = column
                        optionsG = options
                        
        return rowG, columnG, optionsG
        
    def readFromFile(self):
        state = [[0]*10 for i in range(10)]
        with open(self.filename, "r") as f:
            row = 0
            for line in f.readlines():
                line = line.strip()
                line = line.split(";")
                typeP = 0
                for item in line:
                    typeP += 1

                for column in range(0, typeP):
                    state[row][column] = int(line[column])
                row += 1
        
        iState = [[0]*typeP for i in range(typeP)]
        for row in range(0, typeP):
            for column in range(0, typeP):
                    iState[row][column] = state[row][column]
        
        self.initState = iState

        