'''
Created on Mar 10, 2018

@author: Louis
'''
from state.State import State
from _collections import defaultdict, OrderedDict


class Controller(object):
    def __init__(self, problem):
        self.problem = problem
        
    def getProblem(self):
        return self._problem
        
    def bfs(self, p):
        q = []
        vis = []
        q.append(self.problem.initState)
        vis.append(self.problem.initState)
        while len(q) > 0:                         #while there are states in the queue
            now = q.pop(0)                   #get the first one
            if now == self.problem.finalState:
                count = 0
                for x in vis:
                    count += 1
                    for y in x:
                        print(y)
                    print("\n\n")
                print("Number of steps: ", count)
                return now
            for nxt in self.problem.expand(now):
                if nxt not in vis:
                    vis.append(nxt)
                    q.append(nxt)
                    
        return []
    
    def gbfs(self, p):
        q = []
        vis = []
        q.append(self.problem.initState)
        vis.append(self.problem.initState)
        while len(q) > 0:
            now = q.pop(0)
            if now == self.problem.finalState:
                count = 0
                for x in vis:
                    count += 1
                    for y in x:
                        print(y)
                    print("\n\n")
                print("Number of steps: ", count)
                return now
            for nxt in self.problem.expand_gbfs(now):
                if nxt not in vis:
                    vis.append(nxt)
                    q.append(nxt)
        return []
        
    