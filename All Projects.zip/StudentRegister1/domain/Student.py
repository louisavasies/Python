class Student:
    
    
    def __init__(self, _id, _name):
        self.__id = _id
        self.__name = _name

    def get_id(self):
        return self.__id


    def get_name(self):
        return self.__name


    def set_id(self, value):
        self.__id = value


    def set_name(self, value):
        self.__name = value

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__id == other.__id
    
    @staticmethod
    def studentToStr(student):
        return str(student.get_ident())+";"+student.get_name()+";"+str(student.get_average())

    @staticmethod
    def strToStudent(line):
        words = line.split(";")
        return Student(int(words[0]),words[1],float(words[2]))



