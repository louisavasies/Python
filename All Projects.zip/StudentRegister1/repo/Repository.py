class RepoException(Exception):
    pass

class Repository:
    
    
    def __init__(self):
        self._elems = []
    
    def size(self):
        return len(self._elems)
    
    def add(self,elem):
        if elem in self._elems:
            raise RepoException("elem exists!")
        self._elems.append(elem)

    
    def find(self,elem):
        if elem not in self._elems:
            raise RepoException("elem does not exist!")
        idx = self._elems.index(elem)
        return self._elems[idx]

    
    def upd(self,elem):
        if elem not in self._elems:
            raise RepoException("elem does not exist!")
        
        idx = self._elems.index(elem)
        self._elems[idx]=elem

    
    def getAll(self):
        return self._elems[:]

    
    def rem(self,elem):
        if elem not in self._elems:
            raise RepoException("elem does not exist!")
        self._elems.remove(elem)



class FileRepository(Repository):
    
    
    def __readAllFromFile(self):
        with open(self.__txt,"r") as f:
            for line in f.readlines():
                line = line.strip()
                if len(line)>0:
                    obj = self.__strToObj(line)
                    self._elems.append(obj)
    
    def __writeAllToFile(self):
        with open(self.__txt,"w") as f:
            for obj in self._elems:
                line = self.__objToStr(obj)
                f.write(line+"\n")
    
        pass
    
    
    def __init__(self, txt, str_to_student, student_to_str):
        self.txt = txt
        self.str_to_student = str_to_student
        self.student_to_str = student_to_str
        Repository.__init__(self)
        self.__readAllFromFile()
    
    def add(self, elem):
        Repository.add(self, elem)
        self.__writeAllToFile()

    def upd(self, elem):
        Repository.upd(self, elem)
        self.__writeAllToFile()

    def rem(self, elem):
        Repository.rem(self, elem)
        self.__writeAllToFile()




