'''
Created on Mar 24, 2018

@author: Louis
'''

class Problem(object):
    def __init__(self):
        pass
        
    def loadProblem(self):
        pass