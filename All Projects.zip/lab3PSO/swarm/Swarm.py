'''
Created on Mar 24, 2018

@author: Louis
'''

class Swarm(object):
    def __init__(self):
        self.v = []
        self.numberOfParticles = 0
        
    def getBestNeighbour(self, particle):
        pass
    
    def getBestParticles(self):
        pass
    