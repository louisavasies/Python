'''
Created on Mar 24, 2018

@author: Louis
'''

class Controller(object):
    def __init__(self):
        self.population
        
    def iteration(self):
        pass
    
    def runAlgorithm(self):
        pass
    
    def loadParameters(self):
        pass
        