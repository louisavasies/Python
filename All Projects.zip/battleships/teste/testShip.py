'''
Created on Jan 15, 2018

@author: Louis
'''
import unittest
from model.Ship import Ship


class Test(unittest.TestCase):


    def testShip(self):
        tip_ship =2
        orientare_ship = True
        x = 3
        y =7
        ship = Ship(tip_ship,orientare_ship,x,y)
        self.assertEqual(ship.get_tip_ship(), 2)
        self.assertEqual(ship.get_orientare_ship(), True)
        self.assertEqual(ship.get_x(), 3)
        self.assertEqual(ship.get_y(), 7)
        
        self.assertEqual(ship.valid(), True)
        ship.set_y(9)
        self.assertEqual(ship.valid(), False)
        
        ship.set_orientare_ship(False)
        ship.set_x(8)
        ship.set_y(1)
        self.assertEqual(ship.valid(), True)
        
        ship.set_x(9)
        self.assertEqual(ship.valid(), False)
        
        ship.adauga_lovitura(0)
        #ship.adauga_lovitura(1)
        
        self.assertEqual(ship.emort(), False)
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testShip']
    unittest.main()