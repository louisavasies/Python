'''
Created on Jan 15, 2018

@author: Louis
'''
import unittest
from model.Tabla import Tabla

class Test(unittest.TestCase):


    def testTabla(self):
        tabla = Tabla()
        tabla.gen_ran_ships()
        tabla.hit_ship(7, 5)
        print(tabla)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testTabla']
    unittest.main()