'''
Created on Jan 15, 2018

@author: Louis
'''
from model.Ship import Ship
import random


class Tabla(object):

    
    def __init__(self):
        self.__ships = []
        self.__down_ships =[False,False,False]
        self.__visible = True
    
    def set_visible(self,visible):
        self.__visible = visible
    
    def set_ships(self,ships):
        self.__ships =ships
    
    def hit_ship(self,x,y):
        for ship in self.__ships:
            if ship.get_orientare_ship()==False:
                if x == ship.get_x():
                    poz = abs(y - ship.get_y())
                    if ship.adauga_lovitura(poz)==1:
                        raise Exception("Nu a nimerit!")
                    elif ship.adauga_lovitura(poz)==2:
                        raise Exception("Deja nimerit!")
                    else:
                        ship._lovituri[poz] = True
                        print("A nimerit!")  
                else: 
                    print("Nu a nimerit!")              
            else:
                if y == ship.get_y():
                    poz = abs(x - ship.get_x())
                    if ship.adauga_lovitura(poz)==1:
                        raise Exception("Nu a nimerit!")
                    elif ship.adauga_lovitura(poz)==2:
                        raise Exception("Deja nimerit!")
                    else:
                        ship._lovituri[poz] = True
                        print("A nimerit!")
                else: 
                    print("Nu a nimerit!")  
    
    
    def is_over(self):
        for ship in self.__ships:
                if ship.emort() == False:
                    return 0
        return 1
                  
                    
    def gen_ran_ships(self):
        ship_types = [2,3,4]
        for ship_type in ship_types:
            x = random.randint(0,9)
            y = random.randint(0,9)
            orientare = False
            ship = Ship(ship_type, orientare, x, y)
            if not ship.valid():
                ship.set_orientare_ship(True)
            while not ship.valid():
                next = x*10+y+1
                x = next // 10
                y = next % 10
                orientare = False
                ship = Ship(ship_type, orientare, x, y)
                if not ship.valid():
                    ship.set_orientare_ship(True)
            self.__ships.append(ship)
        for ship in self.__ships:
            print(ship)   
    
            
    def __str__(self):
        tabla = [None]*10
        for i in range(10):
            tabla[i] = ['~']*10
        if self.__visible == True:
            for ship in self.__ships:
                for i in range(ship.get_tip_ship()):
                    if ship.get_orientare_ship()==False:
                        if ship.get_lovituri()[i]==True:
                            tabla[ship.get_x()+i][ship.get_y()]='*'
                        if ship.get_lovituri()[i]==False:
                            tabla[ship.get_x()+i][ship.get_y()]='X'
                    else:
                        if ship.get_lovituri()[i]==True:
                            tabla[ship.get_x()][ship.get_y()+i]='*'
                        if ship.get_lovituri()[i]==False:
                            tabla[ship.get_x()][ship.get_y()+i]='X'
        s = ""
        for i in range(10):
            for j in range(10):
                s+=str(tabla[i][j])
            s+="\n"
               
        return s
    
    