'''
Created on Jan 15, 2018

@author: Louis
'''

class Ship(object):
    '''
    classdocs
    '''

    
    def __init__(self, tip_ship, orientare_ship, x, y):
        self.__tip_ship = tip_ship
        self.__orientare_ship = orientare_ship
        self.__x = x
        self.__y = y
        self.__lovituri = [False] * tip_ship
        
    def adauga_lovitura(self, poz):
        if (poz < 0 or poz > self.__tip_ship):
            return 1
        if (self.__lovituri[poz] == True):
            return 2
        self.__lovituri[poz] = True
        return 0
    
    
    def emort(self):
        
        for x in self.__lovituri :
            if x == False:
                return False
        return True
        
        
        

    def get_tip_ship(self):
        return self.__tip_ship


    def get_orientare_ship(self):
        return self.__orientare_ship

    def get_lovituri(self):
        return self.__lovituri
    
    def get_x(self):
        return self.__x


    def get_y(self):
        return self.__y


    def set_tip_ship(self, value):
        self.__tip_ship = value


    def set_orientare_ship(self, value):
        self.__orientare_ship = value


    def set_x(self, value):
        self.__x = value


    def set_y(self, value):
        self.__y = value

    def valid(self):
        if(self.__orientare_ship == True):
            if(self.__y + self.__tip_ship > 10):
                return False
        if(self.__orientare_ship == False):
            if(self.__x + self.__tip_ship > 10):
                return False
        return True

    def __str__(self):
        return str(self.__x)+" "+str(self.__y)+" "+str(self.__tip_ship)+" "+str(self.__orientare_ship)+" "+str(self.__lovituri)

    
    

