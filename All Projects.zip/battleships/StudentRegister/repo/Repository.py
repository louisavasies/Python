class Repository:
    def __init__(self):
        self._elems = []
        
    


class FileRepository(Repository):

    
    def readAllFromFile(self):
        with open(self.__txt, "r") as f:
            for line in f.readlines():
                line = line.strip()
                if len(line) > 0:
                    obj = self.__strToObj(line)
                    self._elems.append(obj)
    
    
    
    def __init__(self, txt, strToObj, objToStr):
        self.txt = txt
        self.strToObj = strToObj
        self.objToStr = objToStr
        Repository.__init__(self)
        self.readAllFromFile()
        
    
    
    
    
    def __writeAllToFile(self):
        with open(self.__txt, "w") as f:
            for obj in self._elems:
                line = self.__objToStr(obj)
                f.write(line+"|n")
    
    
    def add(self, elem):
        Repository.add(self, elem)
        self.__writeAllToFile()
        
    
    

    
    

class RepoException(Exception):
    pass


