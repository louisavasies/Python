'''
Created on Jan 4, 2018

@author: Louis
'''
import unittest
from tests.StudentTest import TestStudent
from repo.Repository import Repository, FileRepository, RepoException
from domain.Student import Student


class TestRepo(TestStudent):
    
    
    def setUp(self):
        TestStudent.setUp(self)
        self._repo = FileRepository("students.txt", Student.strToStudent, Student.studentToStr)


    def tearDown(self):
        pass


    def testName(self):
        TestStudent.testName(self)
        self.assertEqual(0, self._repo.size())
        self._repo.add(self._student)
        self.assertEqual(1, self._repo.size())
        elem = self._repo.find(self._otherstudent)
        self.assertEqual("john", elem.get_name())
        with self.assertRaises(RepoException):
            self._repo.add(self._student)
        with self.assertRaises(RepoException):
            self._repo.find(self._anotherstudent)
            


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()