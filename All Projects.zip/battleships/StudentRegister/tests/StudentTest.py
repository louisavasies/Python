'''
Created on Jan 4, 2018

@author: Louis
'''
import unittest
from domain.Student import Student

class TestStudent(unittest.TestCase):
    

    def setUp(self):
        self._id = 1
        self._name = "john"
        self._otherid = 2
        self._othername = "johnny"
        self._student = Student(self._id, self._name)
        self._otherstudent = Student(self._id, self._othername)
        self._anotherstudent = Student(self._id+1, self._othername)


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._student, self._otherstudent)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()