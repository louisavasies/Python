'''
Created on Jan 15, 2018

@author: Louis
'''
from model.Tabla import Tabla
from model.Ship import Ship

class Console(object):
    '''
    classdocs
    '''


    def __init__(self,tabla,tabla_oponent):
        '''
        Constructor
        '''
        self.__tabla = tabla
        self.__tabla_oponent = tabla_oponent
        

    def __read_command(self):
        return input("Input option:")
    
    def __showMenu(self,options):
        print("0.Exit")
        keys = options.keys()
        for option in keys:
            print(options[option][0])
        
    def __ui_generate_ships(self):
        ship_types = [2,3,4]
        ships = []
        for ship_type in ship_types:
            x = int(input("enter x:"))
            y = int(input("enter y:"))
            orientare = bool(input("enter orientation:"))
            ship = Ship(ship_type, orientare, x, y)
            while not ship.valid():
                x = int(input("enter x:"))
                y = int(input("enter y:"))
                orientare =  bool(input("enter orientation:"))
                ship = Ship(ship_type, orientare, x, y)
            ships.append(ship)
        self.__tabla.set_ships(ships)
        
    def run(self):
        self.__tabla_oponent.gen_ran_ships()
        self.__tabla_oponent.set_visible(False)
        self.__options = {"1":["Generate Ships",self.__ui_generate_ships],"2":["Start Game",self.__ui_start_game]}
        
        while True:
            self.__showMenu(self.__options)
            cmd = self.__read_command()
            if cmd in self.__options:
                try:
                    self.__options[cmd][1]()
                except Exception as ex:
                    print(ex)
            else:
                print("Invalid command!")
        