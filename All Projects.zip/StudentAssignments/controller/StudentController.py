'''
Created on Jan 17, 2018

@author: Louis
'''
from domain.Student import Student
from domain.Validators import ValidatorError, StoreError


class StudentController(object):
    def __init__(self, repository):
        self.__repository = repository

    def get_all(self):
        return self.__repository.get_all()
    
    def add_student(self, Id, Name, Group):
        s = Student(Id, Name, Group)
        try:
            self.__repository.add_item(s)
        except ValidatorError as ve:
            raise StoreError(ex=ve)
        
    def update_student(self, Id, Name, Group):
        pass
    
    def delete_student(self, Id):
        try:
            self.__repository.delete(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def find_student(self, Id):
        try:
            return self.__repository.find_by_id(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def print_students(self):
        return self.__repository.get_all()