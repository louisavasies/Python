'''
Created on Jan 17, 2018

@author: Louis
'''
from domain.Validators import ValidatorError, StoreError
from domain.Grade import Grade

class GradeController(object):
    def __init__(self, repository):
        self.__repository = repository

    def get_all(self):
        return self.__repository.get_all()
    
    def add_garde(self, Id1, Id2, grade):
        s = Grade(Id1, Id2, grade)
        try:
            self.__repository.add_item(s)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    
    def delete_Grade(self, Id):
        try:
            self.__repository.delete(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def find_garde(self, Id):
        try:
            return self.__repository.find_by_id(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def print_grades(self):
        return self.__repository.get_all()