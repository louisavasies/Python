'''
Created on Jan 17, 2018

@author: Louis
'''
from domain.Validators import ValidatorError, StoreError
from domain.Assignment import Assignment

class AssignmentController(object):
    def __init__(self, repository):
        self.__repository = repository

    def get_all(self):
        return self.__repository.get_all()
    
    def add_assignment(self, Id, Descr, Deadline):
        s = Assignment(Id, Descr, Deadline)
        try:
            self.__repository.add_item(s)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def give_ass_stud(self, IdA, IdS):
        for s in self.__repository.__items:
            if s.get_sid() == IdS:
                if s.get_aid() == IdA:
                    given = True
        if given == False:
            self.__repository.add_assignment()



    def update_assignment(self, Id, Descr, Deadline):
        ass = self.__repository.find_by_id()
        self.__repository.delete(ass)
        new = Assignment(Id, Descr, Deadline)
        self.__repository.add_item(new)
        
    
    def delete_assignment(self, Id):
        try:
            self.__repository.delete(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def find_assignment(self, Id):
        try:
            return self.__repository.find_by_id(Id)
        except ValidatorError as ve:
            raise StoreError(ex=ve)

    def print_assignments(self):
        return self.__repository.get_all()