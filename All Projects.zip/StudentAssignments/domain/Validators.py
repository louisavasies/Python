'''
Created on Jan 17, 2018

@author: Louis
'''

class StoreError(Exception):
    def __init__(self, message=None, ex=None):
        Exception.__init__(self, message)
        self.__ex = ex
        self.__message = message

    @property
    def message(self):
        msg = self.__message if self.__message else ""
        if self.__ex is None:
            return msg
        msg = msg + " " + type(self.__ex).__name__ + ": " + str(self.__ex)
        return msg

    def __str__(self):
        return self.message
    
class ValidatorError(StoreError):
    pass

        
class StudentValidator(object):
    def validate(self, stud):
        errors = []
        if not type(stud._id) is int or stud._id <= 0:
            errors.append('Student id must be an integer greater or equal to 1')
        if not stud._name:
            errors.append('Name must be completed')
        if not type(stud._group) is int or stud._group <= 0:
            errors.append('Group must be an integer greater or equal to 1')
        if len(errors) > 0:
            raise ValidatorError(str(errors))
        
class AssignmentValidator(object):
    def validate(self, ass):
        errors = []
        if not type(ass._id) is int or ass._id <= 0:
            errors.append('Student id must be an integer greater or equal to 1')
        if not ass._descr:
            errors.append('Description must be completed')
        if len(errors) > 0:
            raise ValidatorError(str(errors))
        
class GradeValidator(object):
    def validate(self, grd):
        errors = []
        if not type(grd._sid) is int or grd._sid <= 0:
            errors.append('Student id must be an integer greater or equal to 1')
        if not type(grd._aid) is int or grd._aid <= 0:
            errors.append('Assignment id must be an integer greater or equal to 1')
        if not type(grd._grade) is int or grd._grade <= 0 or grd._grade > 10:
            errors.append('Grade must be an int greater or equal to 1 and less or equal to 10')
        if len(errors) > 0:
            raise ValidatorError(str(errors))