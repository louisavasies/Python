'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
import datetime
from domain.Assignment import Assignment

class TestAssignment(unittest.TestCase):


    def setUp(self):
        self._id = 1
        self._descr = "Fundamentals of Programming"
        self._deadline = datetime.date(2018,1,1)
        
        self._assign = Assignment(self._id, self._descr, self._deadline)
        

    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._assign.get_id(), 1)
        self.assertEqual(self._assign.get_descr(), "Fundamentals of Programming")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()