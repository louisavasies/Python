'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
from domain.StudentTest import TestStudent
from domain.TestAssignment import TestAssignment
from domain.Grade import Grade


class TestGrade(unittest.TestCase):


    def setUp(self):
        TestStudent.setUp(self)
        TestAssignment.setUp(self)
        
        self._sid = 1
        self._aid = 1
        self._nota = 10
        
        self._grade = Grade(self._sid, self._aid, self._nota)
        


    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._grade.get_sid(), 1)
        self.assertEqual(self._grade.get_aid(), 1)
        self.assertEqual(self._grade.get_nota(), 10)
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()