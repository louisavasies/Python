'''
Created on Jan 17, 2018

@author: Louis
'''

class Assignment(object):
    
    
    def __init__(self, _id, _descr, _deadline):
        self.__id = _id
        self.__descr = _descr
        self.__deadline = _deadline

    def get_id(self):
        return self.__id


    def get_descr(self):
        return self.__descr


    def get_deadline(self):
        return self.__deadline


    def set_descr(self, value):
        self.__descr = value


    def set_deadline(self, value):
        self.__deadline = value

    def __str__(self):
        return int(self._id)+" || "+self._descr()+" || "+self._deadline()
        

