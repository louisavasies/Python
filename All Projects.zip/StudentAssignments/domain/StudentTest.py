'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
from domain.Student import Student


class TestStudent(unittest.TestCase):


    def setUp(self):
        self._id1 = 1
        self._name = "Vasies Louisa"
        self._group = 927
        
        self._student = Student(self._id1, self._name, self._group)
        

    def tearDown(self):
        pass


    def testName(self):
        self.assertEqual(self._student.get_sid(), 1)
        self.assertEqual(self._student.get_name(), "Vasies Louisa")
        self.assertEqual(self._student.get_group(), 927)
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()