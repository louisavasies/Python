'''
Created on Jan 17, 2018

@author: Louis
'''

class Grade(object):
    
    
    def __init__(self, _sid, _aid, _nota):
        self.__sid = _sid
        self.__aid = _aid
        self.__nota = _nota

    def get_sid(self):
        return self.__sid


    def get_aid(self):
        return self.__aid


    def get_nota(self):
        return self.__nota


    def set_sid(self, value):
        self.__sid = value


    def set_aid(self, value):
        self.__aid = value


    def set_nota(self, value):
        self.__nota = value

    def __str__(self):
        return int(self._sid)+" || "+int(self._aid)+" || "+int(self._value)
