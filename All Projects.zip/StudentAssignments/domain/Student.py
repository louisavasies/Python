'''
Created on Jan 17, 2018

@author: Louis
'''

class Student(object):
    def __init__(self, _Sid, _name, _group):
        self.__sid = _Sid
        self.__name = _name
        self.__group = _group
        self.__ungraded = []
        self.__graded = self.__genGrades()


    def __genGrades(self):
        grades = []
        for i in range (2):  # @UnusedVariable
            assgrd = []
            assgrd.append(0)
            grades.append(assgrd)
        return grades
    
    def get_sid(self):
        return self.__sid


    def get_name(self):
        return self.__name


    def get_group(self):
        return self.__group


    def set_name(self, value):
        self.__name = value


    def set_group(self, value):
        self.__group = value
        
    def __str__(self):
        return int(self._sid)+" || "+self._name+" || "+int(self.__group)
        
        
