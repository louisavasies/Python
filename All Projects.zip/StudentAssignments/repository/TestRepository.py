'''
Created on Jan 17, 2018

@author: Louis
'''
import unittest
from domain.StudentTest import TestStudent
from domain.TestAssignment import TestAssignment
from domain.TestGrade import TestGrade
from domain.Student import Student
from repository.Repository import StudentFileRepository, AssignmentFileRepository, GradeFileRepository
from domain.Grade import Grade
from domain.Assignment import Assignment
from domain.Validators import StudentValidator, AssignmentValidator,\
    GradeValidator




class TestRepository(unittest.TestCase):


    def setUp(self):
        TestStudent.setUp(self)
        TestAssignment.setUp(self)
        TestGrade.setUp(self)
        
        
        self._st_repo = StudentFileRepository(StudentValidator,"students.txt", )
        self._as_repo = AssignmentFileRepository(AssignmentValidator,"assignments.txt", )
        self._gr_repo = GradeFileRepository(GradeValidator,"grades.txt", )
        
        

    def tearDown(self):
        pass


    def testName(self):
        self._st_repo.save(self._student)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()