'''
Created on Jan 17, 2018

@author: Louis
'''

from domain.Validators import StoreError
from domain.Student import Student
from domain.Assignment import Assignment
from _datetime import datetime
from domain.Grade import Grade

class RepositoryError(StoreError):
    pass

class Repository(object):
    def __init__(self, validator):
        self.__items = {}
        self.__validator = validator

    def add_item(self, item):
        self.__validator.validate(item)
        self.__items[item.Id] = item

    def delete(self, Id):
        item = self.find_by_id(Id)
        self.__validator.validate(self.__items[item.Id])
        self.__items.pop(item.Id)

    def update(self, item):
        self.__validator.validate(item)
        for i in range(0, len(self.__items)):
            if i == item.Id:
                self.__items[i] = item
                

    def size(self):
        return len(self.__items)

    def get_all(self):
        return list(self.__items.values())

    def find_by_id(self, Id):
        if not Id in self.__items:
            raise RepositoryError("An item with the given id does not exist")
        return self.__items[Id]
    
    

class StudentFileRepository(Repository):
    def __init__(self,validator,file_name):
        Repository.__init__(self, validator)
        self.__file_name = file_name
        self.__load_students()
        
    def deleteStudent(self, Sid):
        for e in self.__items:
            if e.get_sid() == Sid:
                self.__items.pop(Sid)  
                return 1
        return 0  
        
    
    def updateStudent(self, Id, Name, Group):
        for stud in self.__items:
            if stud.get_sid() == Id:
                stud = self.find_by_id(Id)
                stud.set_name(Name)
                stud.set_group(Group)
                return 1
        return 0
        
    def giveAssToStud(self, Sid, Aid):
        student = self.find_by_id(Sid)
        for assId in range(len(self.__graded)):
            if assId == Aid:
                print("Assignment with ID " + str(Aid) + " already given to " + student._name)
                return 0
        student.__ungraded.append(Aid)
        return 1
        
    def giveAssToGroup(self, Group, Aid):
        found = 0
        for student in self.__items:
            if student.get_group() == Group:
                for assId in range(len(self.__graded)):
                    if assId == Aid:
                        print("Assignment with ID " + str(Aid) + " already given to "+student._name)
                        found = 1
                if found == 0:
                    student.__ungraded.append(Aid)
                    
    
    
    def save(self,item):
        self.add_item(item)
        self.__save_student(item)

    def __load_students(self):
        with open(self.__file_name,"r") as f:
            for line in f.readlines():
                line = line.strip()
                arr = line.split(",")
                s = Student(int(arr[0]),arr[1],int(arr[2]))
                self.add_item(s)
    

    def __save_student(self, Student):
        with open(self.__file_name, "w") as f:
            s = str(Student._sid)+","+Student._name+","+str(Student._group) + "\n"
            f.write(s)
    
class AssignmentFileRepository(Repository):
    def __init__(self,validator,file_name):
        Repository.__init__(self, validator)
        self.__file_name = file_name
        self.__load_assignments()
        
    def updateAssignment(self, Id, Descr, Deadline):
        ass = self.find_by_id(Id)
        ass.set_descr(Descr)
        ass.set_deadline(Deadline)
         
    def save(self,item):
        self.add_item(item)
        self.__save_assignment(item)

    def __load_assignments(self):
        with open(self.__file_name,"r") as f:
            for line in f.readlines():
                line = line.strip()
                arr = line.split(",")
                a = Assignment(int(arr[0]), arr[1], datetime.date(arr[2]))
                self.add_item(a)
                        
    def __save_student(self, Assignment):
        try:
            with open(self.__file_name, "w") as f:
                s = str(Assignment.__id)+","+Assignment.__descr+","+str(Assignment.__deadline) + "\n"
                f.write(s)
        except Exception as ex:
            raise RepositoryError(ex)
    
    
    
class GradeFileRepository(Repository):
    def __init__(self,validator,file_name):
        Repository.__init__(self, validator)
        self.__file_name = file_name
        self.__load_grades()
    
    def save(self,item):
        self.add_item(item)
        self.__save_grade(item)

    def __load_grades(self):
        with open(self.__file_name,"r") as f:
            for line in f.readlines():
                line = line.strip()
                arr = line.split(",")
                g = Grade(int(arr[0]), int(arr[1]), int(arr[2]))
                self.add_item(g)


    def __save_grade(self, Grade):
        try:
            with open(self.__file_name, "w") as f:
                s = str(Grade._sid)+","+str(Grade._aid)+","+str(Grade._nota) + "\n"
                f.write(s)
        except Exception as ex:
            raise RepositoryError(ex)
    

