#include <stdio.h>

int prim(int n)
{
	int d = 3;
	if (n <= 1)
		return 0;
	if (n == 2)
		return 1;
	for (d = 3; d <= n / 2; d += 2)
		if (n%d == 0)
			return 0;
	return 1;
}

int main()
{
	int n, d = 2, c = 0;
	printf("Give n: ");
	scanf("%d", &n);
	//printf("Give d: ");
	//scanf("%d", &d);
	if (!prim(d))
	{
		printf("The given divisor is not prime");
		return 1;
	}
	/*while (n%d == 0)
	{
		n /= d;
		c++;
	}
	*/
	while (n != 1)
	{
		c = 0;
		while (n % d == 0)
		{
			n /= d;
			c++;
		}
		if (c > 0)
			printf("%d^%d\n", d, c);
		d++;
	}
	//printf("Counter is: %d", c);
	getch();
	return 0;
}